"use client"

import { useState, useEffect, useRef, useCallback } from "react"

interface Position {
  latitude: number
  longitude: number
  timestamp: number
  accuracy?: number
}

interface TrackingMetrics {
  distance: number // in meters
  duration: number // in seconds
  averagePace: number // in seconds per km
  currentSpeed: number // in km/h
  elevationGain: number // in meters
  calories: number
  positions: Position[]
}

export function useGPSTracking() {
  const [isTracking, setIsTracking] = useState(false)
  const [isPaused, setIsPaused] = useState(false)
  const [metrics, setMetrics] = useState<TrackingMetrics>({
    distance: 0,
    duration: 0,
    averagePace: 0,
    currentSpeed: 0,
    elevationGain: 0,
    calories: 0,
    positions: [],
  })
  const [currentPosition, setCurrentPosition] = useState<Position | null>(null)
  const [error, setError] = useState<string | null>(null)

  const watchIdRef = useRef<number | null>(null)
  const startTimeRef = useRef<number | null>(null)
  const pausedTimeRef = useRef<number>(0)
  const lastPositionRef = useRef<Position | null>(null)

  // Calculate distance between two coordinates using Haversine formula
  const calculateDistance = useCallback((pos1: Position, pos2: Position): number => {
    const R = 6371000 // Earth's radius in meters
    const dLat = ((pos2.latitude - pos1.latitude) * Math.PI) / 180
    const dLon = ((pos2.longitude - pos1.longitude) * Math.PI) / 180
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((pos1.latitude * Math.PI) / 180) *
        Math.cos((pos2.latitude * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    return R * c
  }, [])

  // Calculate calories burned (rough estimation)
  const calculateCalories = useCallback((distance: number, duration: number): number => {
    // Rough calculation: 60 calories per km for average person
    return Math.round((distance / 1000) * 60)
  }, [])

  // Update metrics when position changes
  const updateMetrics = useCallback(
    (newPosition: Position) => {
      if (!startTimeRef.current || isPaused) return

      const currentTime = Date.now()
      const totalDuration = Math.floor((currentTime - startTimeRef.current - pausedTimeRef.current) / 1000)

      setMetrics((prev) => {
        let newDistance = prev.distance
        const newElevationGain = prev.elevationGain
        let currentSpeed = 0

        if (lastPositionRef.current) {
          const segmentDistance = calculateDistance(lastPositionRef.current, newPosition)

          // Only add distance if movement is significant (reduces GPS noise)
          if (segmentDistance > 5) {
            newDistance += segmentDistance

            // Calculate current speed
            const timeDiff = (newPosition.timestamp - lastPositionRef.current.timestamp) / 1000
            if (timeDiff > 0) {
              currentSpeed = (segmentDistance / timeDiff) * 3.6 // Convert m/s to km/h
            }
          }
        }

        const averagePace = newDistance > 0 ? totalDuration / (newDistance / 1000) : 0
        const calories = calculateCalories(newDistance, totalDuration)

        return {
          distance: newDistance,
          duration: totalDuration,
          averagePace,
          currentSpeed: Math.max(0, currentSpeed),
          elevationGain: newElevationGain,
          calories,
          positions: [...prev.positions, newPosition],
        }
      })

      lastPositionRef.current = newPosition
    },
    [calculateDistance, calculateCalories, isPaused],
  )

  // Start GPS tracking
  const startTracking = useCallback(() => {
    if (!navigator.geolocation) {
      setError("Geolocalização não é suportada neste dispositivo")
      return
    }

    setError(null)
    setIsTracking(true)
    setIsPaused(false)
    startTimeRef.current = Date.now()
    pausedTimeRef.current = 0

    // Reset metrics
    setMetrics({
      distance: 0,
      duration: 0,
      averagePace: 0,
      currentSpeed: 0,
      elevationGain: 0,
      calories: 0,
      positions: [],
    })

    watchIdRef.current = navigator.geolocation.watchPosition(
      (position) => {
        const newPosition: Position = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          timestamp: Date.now(),
          accuracy: position.coords.accuracy,
        }

        setCurrentPosition(newPosition)
        updateMetrics(newPosition)
      },
      (error) => {
        console.error("GPS Error:", error)
        setError("Erro ao acessar GPS. Verifique as permissões de localização.")
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 1000,
      },
    )
  }, [updateMetrics])

  // Pause/Resume tracking
  const togglePause = useCallback(() => {
    if (!isTracking) return

    if (isPaused) {
      // Resume
      const pauseDuration = Date.now() - (pausedTimeRef.current || 0)
      pausedTimeRef.current += pauseDuration
      setIsPaused(false)
    } else {
      // Pause
      pausedTimeRef.current = Date.now()
      setIsPaused(true)
    }
  }, [isTracking, isPaused])

  // Stop tracking
  const stopTracking = useCallback(() => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current)
      watchIdRef.current = null
    }

    setIsTracking(false)
    setIsPaused(false)
    startTimeRef.current = null
    pausedTimeRef.current = 0
    lastPositionRef.current = null
  }, [])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current)
      }
    }
  }, [])

  return {
    isTracking,
    isPaused,
    metrics,
    currentPosition,
    error,
    startTracking,
    togglePause,
    stopTracking,
  }
}
