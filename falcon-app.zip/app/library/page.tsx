"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Book, Search, Filter, Star, Users, BookOpen, Video, FileText, Zap } from "lucide-react"
import Link from "next/link"
import { BookCard } from "@/components/book-card"
import { VideoCard } from "@/components/video-card"
import { ArticleCard } from "@/components/article-card"

const categories = [
  { id: "all", name: "Todos", count: 45 },
  { id: "technique", name: "Técnica", count: 12 },
  { id: "training", name: "Treinamento", count: 15 },
  { id: "nutrition", name: "Nutrição", count: 8 },
  { id: "psychology", name: "Psicologia", count: 6 },
  { id: "injury", name: "Prevenção", count: 4 },
]

const featuredBooks = [
  {
    id: 1,
    title: "Fundamentos do Atletismo",
    author: "Dr. Carlos Silva",
    description: "Guia completo sobre técnicas básicas de corrida, salto e arremesso para jovens atletas.",
    category: "technique",
    level: "Iniciante",
    pages: 180,
    rating: 4.8,
    downloadUrl: "https://example.com/book1.pdf",
    coverImage: "/placeholder-p0542.png",
    tags: ["corrida", "técnica", "iniciante"],
  },
  {
    id: 2,
    title: "Nutrição Esportiva para Jovens",
    author: "Dra. Ana Santos",
    description: "Estratégias nutricionais específicas para atletas em desenvolvimento.",
    category: "nutrition",
    level: "Intermediário",
    pages: 220,
    rating: 4.9,
    downloadUrl: "https://example.com/book2.pdf",
    coverImage: "/sports-nutrition-book.png",
    tags: ["nutrição", "jovens", "performance"],
  },
  {
    id: 3,
    title: "Psicologia do Esporte",
    author: "Prof. João Oliveira",
    description: "Técnicas mentais para melhorar o desempenho e lidar com a pressão competitiva.",
    category: "psychology",
    level: "Avançado",
    pages: 195,
    rating: 4.7,
    downloadUrl: "https://example.com/book3.pdf",
    coverImage: "/placeholder-aqp7z.png",
    tags: ["mental", "competição", "foco"],
  },
  {
    id: 4,
    title: "Treinamento Intervalado",
    author: "Coach Maria Lima",
    description: "Métodos modernos de treinamento intervalado para melhorar velocidade e resistência.",
    category: "training",
    level: "Intermediário",
    pages: 160,
    rating: 4.6,
    downloadUrl: "https://example.com/book4.pdf",
    coverImage: "/placeholder-wn6wn.png",
    tags: ["treino", "velocidade", "resistência"],
  },
]

const videos = [
  {
    id: 1,
    title: "Técnica de Corrida Perfeita",
    instructor: "Coach Pedro",
    duration: "15:30",
    views: "12.5k",
    thumbnail: "/running-technique-video.png",
    url: "https://youtube.com/watch?v=example1",
    category: "technique",
  },
  {
    id: 2,
    title: "Aquecimento Dinâmico",
    instructor: "Dra. Carla",
    duration: "8:45",
    views: "8.2k",
    thumbnail: "/dynamic-warmup.png",
    url: "https://youtube.com/watch?v=example2",
    category: "training",
  },
  {
    id: 3,
    title: "Nutrição Pré-Treino",
    instructor: "Nutri Ana",
    duration: "12:20",
    views: "15.1k",
    thumbnail: "/pre-workout-nutrition-video.png",
    url: "https://youtube.com/watch?v=example3",
    category: "nutrition",
  },
]

const articles = [
  {
    id: 1,
    title: "Como Evitar Lesões na Corrida",
    author: "Dr. Roberto",
    readTime: "5 min",
    publishDate: "2025-01-15",
    excerpt: "Dicas essenciais para prevenir lesões comuns em corredores jovens...",
    url: "https://example.com/article1",
    category: "injury",
  },
  {
    id: 2,
    title: "Periodização para Jovens Atletas",
    author: "Coach Sandra",
    readTime: "8 min",
    publishDate: "2025-01-12",
    excerpt: "Estratégias de periodização adaptadas para atletas em desenvolvimento...",
    url: "https://example.com/article2",
    category: "training",
  },
  {
    id: 3,
    title: "Hidratação Durante Competições",
    author: "Dra. Fernanda",
    readTime: "6 min",
    publishDate: "2025-01-10",
    excerpt: "Protocolos de hidratação para manter o desempenho em competições...",
    url: "https://example.com/article3",
    category: "nutrition",
  },
]

export default function AthleticLibrary() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedLevel, setSelectedLevel] = useState("all")

  const filteredBooks = featuredBooks.filter((book) => {
    const matchesSearch =
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))

    const matchesCategory = selectedCategory === "all" || book.category === selectedCategory
    const matchesLevel = selectedLevel === "all" || book.level === selectedLevel

    return matchesSearch && matchesCategory && matchesLevel
  })

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="sm" className="gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Voltar
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
                  <Book className="w-5 h-5 text-accent-foreground" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold font-serif text-primary">Biblioteca Atlética</h1>
                  <p className="text-sm text-muted-foreground">Recursos educacionais para jovens atletas</p>
                </div>
              </div>
            </div>
            <Badge variant="secondary" className="font-medium">
              45 Recursos
            </Badge>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Buscar livros, autores ou tópicos..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2">
            <select
              value={selectedLevel}
              onChange={(e) => setSelectedLevel(e.target.value)}
              className="px-3 py-2 border border-border rounded-md bg-background text-foreground"
            >
              <option value="all">Todos os Níveis</option>
              <option value="Iniciante">Iniciante</option>
              <option value="Intermediário">Intermediário</option>
              <option value="Avançado">Avançado</option>
            </select>
            <Button variant="outline" size="sm" className="gap-2 bg-transparent">
              <Filter className="w-4 h-4" />
              Filtros
            </Button>
          </div>
        </div>

        {/* Categories */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category.id)}
              className="whitespace-nowrap"
            >
              {category.name} ({category.count})
            </Button>
          ))}
        </div>

        <Tabs defaultValue="books" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="books" className="gap-2">
              <BookOpen className="w-4 h-4" />
              Livros
            </TabsTrigger>
            <TabsTrigger value="videos" className="gap-2">
              <Video className="w-4 h-4" />
              Vídeos
            </TabsTrigger>
            <TabsTrigger value="articles" className="gap-2">
              <FileText className="w-4 h-4" />
              Artigos
            </TabsTrigger>
          </TabsList>

          <TabsContent value="books" className="space-y-6">
            {/* Featured Section */}
            <div>
              <h2 className="text-xl font-bold font-serif mb-4">Livros em Destaque</h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredBooks.map((book) => (
                  <BookCard key={book.id} book={book} />
                ))}
              </div>
            </div>

            {/* Quick Access Categories */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 font-serif text-lg">
                    <Zap className="w-5 h-5 text-primary" />
                    Técnicas de Corrida
                  </CardTitle>
                  <CardDescription>12 recursos sobre biomecânica e técnica</CardDescription>
                </CardHeader>
              </Card>
              <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 font-serif text-lg">
                    <Users className="w-5 h-5 text-accent" />
                    Treinamento em Grupo
                  </CardTitle>
                  <CardDescription>8 guias para treinos coletivos</CardDescription>
                </CardHeader>
              </Card>
              <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 font-serif text-lg">
                    <Star className="w-5 h-5 text-primary" />
                    Preparação Mental
                  </CardTitle>
                  <CardDescription>6 livros sobre psicologia esportiva</CardDescription>
                </CardHeader>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="videos" className="space-y-6">
            <div>
              <h2 className="text-xl font-bold font-serif mb-4">Vídeos Educacionais</h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {videos.map((video) => (
                  <VideoCard key={video.id} video={video} />
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="articles" className="space-y-6">
            <div>
              <h2 className="text-xl font-bold font-serif mb-4">Artigos Recentes</h2>
              <div className="space-y-4">
                {articles.map((article) => (
                  <ArticleCard key={article.id} article={article} />
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
