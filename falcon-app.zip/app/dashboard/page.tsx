"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, Target, Clock, MapPin, Zap, Trophy, Activity, Plus, Filter } from "lucide-react"
import Link from "next/link"
import { WeeklyChart } from "@/components/weekly-chart"
import { RecentWorkouts } from "@/components/recent-workouts"
import { GoalsOverview } from "@/components/goals-overview"
import { PerformanceMetrics } from "@/components/performance-metrics"

export default function TrainingDashboard() {
  const [selectedPeriod, setSelectedPeriod] = useState("week")

  // Mock data - in real app this would come from database/API
  const weeklyStats = {
    totalDistance: 18.5,
    totalTime: 142, // minutes
    averagePace: 6.2, // min/km
    workoutsCompleted: 4,
    caloriesBurned: 1240,
    weeklyGoal: 25,
  }

  const monthlyStats = {
    totalDistance: 78.2,
    totalTime: 612, // minutes
    averagePace: 6.1,
    workoutsCompleted: 16,
    caloriesBurned: 5240,
    monthlyGoal: 100,
  }

  const currentStats = selectedPeriod === "week" ? weeklyStats : monthlyStats

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="sm" className="gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Voltar
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold font-serif text-primary">Dashboard de Treinos</h1>
                <p className="text-sm text-muted-foreground">Acompanhe seu progresso atlético</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                <Filter className="w-4 h-4" />
                Filtros
              </Button>
              <Link href="/">
                <Button size="sm" className="gap-2">
                  <Plus className="w-4 h-4" />
                  Novo Treino
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Visão Geral</TabsTrigger>
            <TabsTrigger value="workouts">Treinos</TabsTrigger>
            <TabsTrigger value="goals">Metas</TabsTrigger>
            <TabsTrigger value="analytics">Análises</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Period Selector */}
            <div className="flex gap-2">
              <Button
                variant={selectedPeriod === "week" ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedPeriod("week")}
              >
                Esta Semana
              </Button>
              <Button
                variant={selectedPeriod === "month" ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedPeriod("month")}
              >
                Este Mês
              </Button>
            </div>

            {/* Key Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <MapPin className="w-6 h-6 text-primary mx-auto mb-2" />
                  <div className="text-2xl font-bold">{currentStats.totalDistance}km</div>
                  <div className="text-sm text-muted-foreground">distância total</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Clock className="w-6 h-6 text-accent mx-auto mb-2" />
                  <div className="text-2xl font-bold">
                    {Math.floor(currentStats.totalTime / 60)}h {currentStats.totalTime % 60}m
                  </div>
                  <div className="text-sm text-muted-foreground">tempo total</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Zap className="w-6 h-6 text-primary mx-auto mb-2" />
                  <div className="text-2xl font-bold">{currentStats.averagePace}'</div>
                  <div className="text-sm text-muted-foreground">ritmo médio</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Activity className="w-6 h-6 text-accent mx-auto mb-2" />
                  <div className="text-2xl font-bold">{currentStats.workoutsCompleted}</div>
                  <div className="text-sm text-muted-foreground">treinos</div>
                </CardContent>
              </Card>
            </div>

            {/* Progress Towards Goals */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-serif">
                  <Target className="w-5 h-5 text-primary" />
                  Progresso da Meta {selectedPeriod === "week" ? "Semanal" : "Mensal"}
                </CardTitle>
                <CardDescription>
                  Meta: {selectedPeriod === "week" ? weeklyStats.weeklyGoal : monthlyStats.monthlyGoal}km
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>
                      {currentStats.totalDistance}km de{" "}
                      {selectedPeriod === "week" ? weeklyStats.weeklyGoal : monthlyStats.monthlyGoal}km
                    </span>
                    <span className="text-accent font-medium">
                      {Math.round(
                        (currentStats.totalDistance /
                          (selectedPeriod === "week" ? weeklyStats.weeklyGoal : monthlyStats.monthlyGoal)) *
                          100,
                      )}
                      %
                    </span>
                  </div>
                  <Progress
                    value={
                      (currentStats.totalDistance /
                        (selectedPeriod === "week" ? weeklyStats.weeklyGoal : monthlyStats.monthlyGoal)) *
                      100
                    }
                    className="h-3"
                  />
                  <p className="text-sm text-muted-foreground">
                    Faltam{" "}
                    {Math.max(
                      0,
                      (selectedPeriod === "week" ? weeklyStats.weeklyGoal : monthlyStats.monthlyGoal) -
                        currentStats.totalDistance,
                    ).toFixed(1)}
                    km para atingir sua meta!
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Weekly Performance Chart */}
            <WeeklyChart />

            {/* Recent Achievements */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-serif">
                  <Trophy className="w-5 h-5 text-accent" />
                  Conquistas Recentes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-accent/10 rounded-lg">
                    <div className="w-10 h-10 bg-accent rounded-full flex items-center justify-center">
                      <Trophy className="w-5 h-5 text-accent-foreground" />
                    </div>
                    <div>
                      <h4 className="font-medium">Melhor Ritmo Pessoal!</h4>
                      <p className="text-sm text-muted-foreground">5:45/km - Novo recorde</p>
                    </div>
                    <Badge variant="secondary" className="ml-auto">
                      Hoje
                    </Badge>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-primary/10 rounded-lg">
                    <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                      <Target className="w-5 h-5 text-primary-foreground" />
                    </div>
                    <div>
                      <h4 className="font-medium">Meta Semanal Atingida</h4>
                      <p className="text-sm text-muted-foreground">25km completados</p>
                    </div>
                    <Badge variant="secondary" className="ml-auto">
                      2 dias
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="workouts" className="space-y-6">
            <RecentWorkouts />
          </TabsContent>

          <TabsContent value="goals" className="space-y-6">
            <GoalsOverview />
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <PerformanceMetrics />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
