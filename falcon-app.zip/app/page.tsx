"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Play,
  Pause,
  Square,
  MapPin,
  Zap,
  Target,
  Book,
  Newspaper,
  AlertCircle,
  Clock,
  TrendingUp,
  BarChart3,
  SettingsIcon,
  Calendar,
  History,
  AlertTriangle,
  Satellite,
} from "lucide-react"
import Link from "next/link"
import { useGPSTracking } from "@/hooks/use-gps-tracking"
import { GPSMap } from "@/components/gps-map"
import TrainingMetricsDisplay from "@/components/training-metrics"
import GoalsManager from "@/components/goals-manager"
import TrainingPlanner from "@/components/training-planner"
import Navigation from "@/components/navigation"
import TrainingPlans from "@/components/training-plans"
import Challenges from "@/components/challenges"
import Community from "@/components/community"
import ProgressDashboard from "@/components/progress-dashboard"
import RunHistory from "@/components/run-history"
import LiveMap from "@/components/live-map"
import { useState } from "react"

interface GPSCoordinate {
  latitude: number
  longitude: number
  timestamp: number
  accuracy: number
  altitude?: number
}

interface RunData {
  distance: number
  duration: number
  pace: number
  isRunning: boolean
  isPaused: boolean
  gpsCoordinates: GPSCoordinate[]
  currentLocation: GPSCoordinate | null
  elevation: number
  totalElevationGain: number
}

interface GPSStatus {
  isEnabled: boolean
  accuracy: number | null
  error: string | null
}

interface SavedRun {
  id: string
  name: string
  date: Date
  distance: number
  duration: number
  pace: number
  elevationGain: number
  gpsCoordinates: Array<{
    latitude: number
    longitude: number
    timestamp: number
  }>
}

export default function FalconApp() {
  const { isTracking, isPaused, metrics, currentPosition, error, startTracking, togglePause, stopTracking } =
    useGPSTracking()
  const [showGoals, setShowGoals] = useState(false)
  const [showPlanner, setShowPlanner] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [showProgress, setShowProgress] = useState(false)
  const [showHistory, setShowHistory] = useState(false)
  const [currentView, setCurrentView] = useState("home")
  const [userPoints, setUserPoints] = useState(1250)
  const [unreadMessages, setUnreadMessages] = useState(3)
  const [savedRuns, setSavedRuns] = useState<SavedRun[]>([])
  const [runData] = useState<RunData>({
    distance: 0,
    duration: 0,
    pace: 0,
    isRunning: false,
    isPaused: false,
    gpsCoordinates: [],
    currentLocation: null,
    elevation: 0,
    totalElevationGain: 0,
  })
  const gpsStatus = { error: null, isEnabled: true, accuracy: 10 }

  if (showGoals) {
    return <GoalsManager savedRuns={metrics.savedRuns} onBack={() => setShowGoals(false)} />
  }

  if (showPlanner) {
    return <TrainingPlanner onBack={() => setShowPlanner(false)} />
  }

  if (showProgress) {
    return <ProgressDashboard savedRuns={savedRuns} onBack={() => setShowProgress(false)} />
  }

  if (showHistory) {
    return <RunHistory savedRuns={savedRuns} onBack={() => setShowHistory(false)} />
  }

  if (currentView === "training") {
    return <TrainingPlans onBack={() => setCurrentView("home")} />
  }

  if (currentView === "challenges") {
    return <Challenges onBack={() => setCurrentView("home")} />
  }

  if (currentView === "community") {
    return <Community onBack={() => setCurrentView("home")} />
  }

  if (currentView === "achievements") {
    return <ProgressDashboard savedRuns={metrics.savedRuns} onBack={() => setCurrentView("home")} />
  }

  if (currentView === "analytics") {
    return <RunHistory savedRuns={metrics.savedRuns} onBack={() => setCurrentView("home")} />
  }

  return (
    <div className="min-h-screen bg-background p-4 space-y-6">
      <div className="flex items-center justify-between">
        <div className="text-center flex-1">
          <h1 className="font-serif text-3xl font-bold text-primary">Falcon</h1>
          <p className="text-muted-foreground">Evolua no atletismo</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => setShowSettings(true)} className="flex items-center gap-2">
            <SettingsIcon className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={() => setShowGoals(true)} className="flex items-center gap-2">
            <Target className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={() => setShowPlanner(true)} className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={() => setShowProgress(true)} className="flex items-center gap-2">
            <Target className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={() => setShowHistory(true)} className="flex items-center gap-2">
            <History className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-primary-foreground" />
              </div>
              <h1 className="text-2xl font-bold font-serif text-primary">Falcon</h1>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="font-medium">
                Jovem Atleta
              </Badge>
              <Link href="/dashboard">
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <BarChart3 className="w-4 h-4" />
                  Dashboard
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 space-y-6">
        {/* Error Alert */}
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {gpsStatus.error && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{gpsStatus.error}</AlertDescription>
          </Alert>
        )}

        {gpsStatus.isEnabled && (
          <Alert>
            <Satellite className="h-4 w-4" />
            <AlertDescription>
              GPS ativo - Precisão: {gpsStatus.accuracy ? `${gpsStatus.accuracy.toFixed(0)}m` : "Calculando..."}
            </AlertDescription>
          </Alert>
        )}

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <MapPin className="w-6 h-6 text-primary mx-auto mb-2" />
              <div className="text-2xl font-bold">5.2</div>
              <div className="text-sm text-muted-foreground">km hoje</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Clock className="w-6 h-6 text-accent mx-auto mb-2" />
              <div className="text-2xl font-bold">32:15</div>
              <div className="text-sm text-muted-foreground">tempo</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Zap className="w-6 h-6 text-primary mx-auto mb-2" />
              <div className="text-2xl font-bold">6:12</div>
              <div className="text-sm text-muted-foreground">ritmo/km</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-6 h-6 text-accent mx-auto mb-2" />
              <div className="text-2xl font-bold">245</div>
              <div className="text-sm text-muted-foreground">calorias</div>
            </CardContent>
          </Card>
        </div>

        {/* Real-time Metrics */}
        <TrainingMetricsDisplay metrics={metrics} isTracking={isTracking} />

        {/* Live Map Component */}
        <LiveMap
          coordinates={runData.gpsCoordinates}
          currentLocation={runData.currentLocation}
          isRunning={runData.isRunning && !runData.isPaused}
        />

        {/* GPS Tracking Section */}
        <Card className="bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 font-serif">
              <MapPin className="w-5 h-5 text-primary" />
              Rastreamento GPS
              {isTracking && (
                <Badge variant={isPaused ? "secondary" : "default"} className="ml-2">
                  {isPaused ? "Pausado" : "Ativo"}
                </Badge>
              )}
            </CardTitle>
            <CardDescription>
              {isTracking
                ? isPaused
                  ? "Treino pausado - toque para continuar"
                  : "Registrando sua corrida em tempo real"
                : "Inicie um novo treino para começar o rastreamento"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* GPS Map */}
            <GPSMap currentPosition={currentPosition} positions={metrics.positions} isTracking={isTracking} />

            {/* Control Buttons */}
            <div className="flex gap-2 justify-center">
              {!isTracking ? (
                <Button onClick={startTracking} size="lg" className="gap-2">
                  <Play className="w-5 h-5" />
                  Iniciar Treino
                </Button>
              ) : (
                <>
                  <Button
                    onClick={togglePause}
                    variant={isPaused ? "default" : "secondary"}
                    size="lg"
                    className="gap-2"
                  >
                    {isPaused ? <Play className="w-5 h-5" /> : <Pause className="w-5 h-5" />}
                    {isPaused ? "Continuar" : "Pausar"}
                  </Button>
                  <Button onClick={stopTracking} variant="destructive" size="lg" className="gap-2">
                    <Square className="w-5 h-5" />
                    Finalizar
                  </Button>
                </>
              )}
            </div>

            {/* Live Stats During Tracking */}
            {isTracking && currentPosition && (
              <div className="bg-card/50 rounded-lg p-4 space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Precisão GPS:</span>
                  <span className="text-sm font-medium">
                    {currentPosition.accuracy ? `±${Math.round(currentPosition.accuracy)}m` : "N/A"}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Posições registradas:</span>
                  <span className="text-sm font-medium">{metrics.positions.length}</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Progress Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 font-serif">
              <Target className="w-5 h-5 text-accent" />
              Progresso Semanal
            </CardTitle>
            <CardDescription>Meta: 25km esta semana</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>{((metrics.distance + 18500) / 1000).toFixed(1)} km de 25 km</span>
                <span className="text-accent font-medium">
                  {Math.round(((metrics.distance + 18500) / 25000) * 100)}%
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-3">
                <div
                  className="bg-gradient-to-r from-primary to-accent h-3 rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(((metrics.distance + 18500) / 25000) * 100, 100)}%` }}
                ></div>
              </div>
              <p className="text-sm text-muted-foreground">
                Faltam {Math.max(0, (25000 - metrics.distance - 18500) / 1000).toFixed(1)} km para atingir sua meta!
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Navigation Cards */}
        <div className="grid md:grid-cols-2 gap-4">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setShowProgress(true)}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 font-serif text-lg">
                <Target className="w-5 h-5 text-primary" />
                Estatísticas
              </CardTitle>
              <CardDescription>Visualize seu desempenho e evolução</CardDescription>
            </CardHeader>
          </Card>

          <Link href="/library">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-serif text-lg">
                  <Book className="w-5 h-5 text-accent" />
                  Biblioteca Atlética
                </CardTitle>
                <CardDescription>Livros e recursos sobre atletismo</CardDescription>
              </CardHeader>
            </Card>
          </Link>
        </div>

        {/* News Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 font-serif">
              <Newspaper className="w-5 h-5 text-primary" />
              Notícias do Atletismo
            </CardTitle>
            <CardDescription>Últimas novidades do mundo atlético</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="border-l-4 border-primary pl-4">
                <h4 className="font-medium">Campeonato Juvenil 2025</h4>
                <p className="text-sm text-muted-foreground">Inscrições abertas até março</p>
              </div>
              <div className="border-l-4 border-accent pl-4">
                <h4 className="font-medium">Dicas de Nutrição Esportiva</h4>
                <p className="text-sm text-muted-foreground">Como melhorar seu desempenho</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Bottom Navigation */}
      <Navigation
        currentView={currentView}
        onViewChange={setCurrentView}
        userPoints={userPoints}
        unreadMessages={unreadMessages}
      />
    </div>
  )
}
