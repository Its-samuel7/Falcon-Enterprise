"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Trophy, Users, Calendar, Target, Flame, Star, Medal, Clock, MapPin, TrendingUp } from "lucide-react"

interface Challenge {
  id: string
  name: string
  description: string
  type: "individual" | "team" | "community"
  category: "distance" | "time" | "frequency" | "speed"
  target: number
  current: number
  unit: string
  startDate: Date
  endDate: Date
  participants: number
  reward: {
    points: number
    badge?: string
    title?: string
  }
  difficulty: "fácil" | "médio" | "difícil" | "extremo"
  isActive: boolean
  completed: boolean
}

interface ChallengesProps {
  onBack: () => void
}

export default function Challenges({ onBack }: ChallengesProps) {
  const [activeTab, setActiveTab] = useState("weekly")
  const [userChallenges, setUserChallenges] = useState<Challenge[]>([])

  const challenges: Challenge[] = [
    {
      id: "weekly-5k",
      name: "5K Esta Semana",
      description: "Complete 5km em uma única corrida",
      type: "individual",
      category: "distance",
      target: 5,
      current: 2.3,
      unit: "km",
      startDate: new Date(),
      endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      participants: 1,
      reward: { points: 100, badge: "Primeira 5K" },
      difficulty: "fácil",
      isActive: true,
      completed: false,
    },
    {
      id: "weekly-consistency",
      name: "Consistência Semanal",
      description: "Corra pelo menos 3 vezes esta semana",
      type: "individual",
      category: "frequency",
      target: 3,
      current: 1,
      unit: "corridas",
      startDate: new Date(),
      endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      participants: 1,
      reward: { points: 150, title: "Corredor Consistente" },
      difficulty: "médio",
      isActive: true,
      completed: false,
    },
    {
      id: "team-marathon",
      name: "Maratona em Equipe",
      description: "Sua equipe deve somar 42km esta semana",
      type: "team",
      category: "distance",
      target: 42,
      current: 18.5,
      unit: "km",
      startDate: new Date(),
      endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      participants: 5,
      reward: { points: 300, badge: "Maratonista em Equipe" },
      difficulty: "difícil",
      isActive: true,
      completed: false,
    },
    {
      id: "community-10k",
      name: "10K Comunitário",
      description: "A comunidade deve somar 1000km este mês",
      type: "community",
      category: "distance",
      target: 1000,
      current: 347,
      unit: "km",
      startDate: new Date(),
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      participants: 156,
      reward: { points: 500, badge: "Herói da Comunidade" },
      difficulty: "extremo",
      isActive: true,
      completed: false,
    },
  ]

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "fácil":
        return "bg-green-500"
      case "médio":
        return "bg-yellow-500"
      case "difícil":
        return "bg-orange-500"
      case "extremo":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "individual":
        return <Target className="h-4 w-4" />
      case "team":
        return <Users className="h-4 w-4" />
      case "community":
        return <TrendingUp className="h-4 w-4" />
      default:
        return <Trophy className="h-4 w-4" />
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "distance":
        return <MapPin className="h-3 w-3" />
      case "time":
        return <Clock className="h-3 w-3" />
      case "frequency":
        return <Calendar className="h-3 w-3" />
      case "speed":
        return <Flame className="h-3 w-3" />
      default:
        return <Star className="h-3 w-3" />
    }
  }

  const getTimeRemaining = (endDate: Date) => {
    const now = new Date()
    const diff = endDate.getTime() - now.getTime()
    const days = Math.floor(diff / (1000 * 60 * 60 * 24))
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))

    if (days > 0) return `${days}d ${hours}h`
    return `${hours}h`
  }

  const weeklyChallenge = challenges.filter((c) => c.type === "individual")
  const teamChallenges = challenges.filter((c) => c.type === "team")
  const communityChallenges = challenges.filter((c) => c.type === "community")

  return (
    <div className="min-h-screen bg-background p-4 pb-20 space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={onBack}>
          ← Voltar
        </Button>
        <h1 className="font-serif text-2xl font-bold text-primary">Desafios</h1>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="weekly">Semanais</TabsTrigger>
          <TabsTrigger value="team">Equipe</TabsTrigger>
          <TabsTrigger value="community">Comunidade</TabsTrigger>
        </TabsList>

        <TabsContent value="weekly" className="space-y-4 mt-6">
          {weeklyChallenge.map((challenge) => {
            const progress = (challenge.current / challenge.target) * 100

            return (
              <Card key={challenge.id} className="relative overflow-hidden">
                <div className={`absolute top-0 left-0 w-1 h-full ${getDifficultyColor(challenge.difficulty)}`} />
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      {getTypeIcon(challenge.type)}
                      <CardTitle className="text-lg">{challenge.name}</CardTitle>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {getTimeRemaining(challenge.endDate)}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{challenge.description}</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="flex items-center gap-1">
                        {getCategoryIcon(challenge.category)}
                        Progresso
                      </span>
                      <span>
                        {challenge.current}/{challenge.target} {challenge.unit}
                      </span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className={`h-2 w-2 rounded-full ${getDifficultyColor(challenge.difficulty)}`} />
                      <span className="text-xs text-muted-foreground capitalize">{challenge.difficulty}</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Trophy className="h-3 w-3" />+{challenge.reward.points} pts
                      {challenge.reward.badge && (
                        <>
                          <Medal className="h-3 w-3" />
                          {challenge.reward.badge}
                        </>
                      )}
                    </div>
                  </div>

                  {progress >= 100 ? (
                    <Button className="w-full" disabled>
                      <Trophy className="h-4 w-4 mr-2" />
                      Concluído!
                    </Button>
                  ) : (
                    <Button className="w-full bg-transparent" variant="outline">
                      Participar
                    </Button>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </TabsContent>

        <TabsContent value="team" className="space-y-4 mt-6">
          {teamChallenges.map((challenge) => {
            const progress = (challenge.current / challenge.target) * 100

            return (
              <Card key={challenge.id} className="relative overflow-hidden">
                <div className={`absolute top-0 left-0 w-1 h-full ${getDifficultyColor(challenge.difficulty)}`} />
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      {getTypeIcon(challenge.type)}
                      <CardTitle className="text-lg">{challenge.name}</CardTitle>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {challenge.participants} membros
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{challenge.description}</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="flex items-center gap-1">
                        {getCategoryIcon(challenge.category)}
                        Progresso da Equipe
                      </span>
                      <span>
                        {challenge.current}/{challenge.target} {challenge.unit}
                      </span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className={`h-2 w-2 rounded-full ${getDifficultyColor(challenge.difficulty)}`} />
                      <span className="text-xs text-muted-foreground capitalize">{challenge.difficulty}</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Trophy className="h-3 w-3" />+{challenge.reward.points} pts
                    </div>
                  </div>

                  <Button className="w-full bg-transparent" variant="outline">
                    <Users className="h-4 w-4 mr-2" />
                    Contribuir para Equipe
                  </Button>
                </CardContent>
              </Card>
            )
          })}
        </TabsContent>

        <TabsContent value="community" className="space-y-4 mt-6">
          {communityChallenges.map((challenge) => {
            const progress = (challenge.current / challenge.target) * 100

            return (
              <Card key={challenge.id} className="relative overflow-hidden">
                <div className={`absolute top-0 left-0 w-1 h-full ${getDifficultyColor(challenge.difficulty)}`} />
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      {getTypeIcon(challenge.type)}
                      <CardTitle className="text-lg">{challenge.name}</CardTitle>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {challenge.participants} atletas
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{challenge.description}</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="flex items-center gap-1">
                        {getCategoryIcon(challenge.category)}
                        Progresso Comunitário
                      </span>
                      <span>
                        {challenge.current}/{challenge.target} {challenge.unit}
                      </span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className={`h-2 w-2 rounded-full ${getDifficultyColor(challenge.difficulty)}`} />
                      <span className="text-xs text-muted-foreground capitalize">{challenge.difficulty}</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Trophy className="h-3 w-3" />+{challenge.reward.points} pts
                    </div>
                  </div>

                  <Button className="w-full bg-transparent" variant="outline">
                    <TrendingUp className="h-4 w-4 mr-2" />
                    Contribuir para Comunidade
                  </Button>
                </CardContent>
              </Card>
            )
          })}
        </TabsContent>
      </Tabs>
    </div>
  )
}
