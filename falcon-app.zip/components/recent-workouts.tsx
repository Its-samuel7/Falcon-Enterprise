"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { MapPin, Clock, Zap, Calendar, MoreHorizontal, Play } from "lucide-react"

const recentWorkouts = [
  {
    id: 1,
    name: "Corrida Matinal",
    date: "2025-01-20",
    distance: 8.2,
    duration: 47, // minutes
    pace: 5.8,
    calories: 520,
    type: "Corrida",
  },
  {
    id: 2,
    name: "Treino Intervalado",
    date: "2025-01-18",
    distance: 6.1,
    duration: 36,
    pace: 5.9,
    calories: 410,
    type: "Intervalado",
  },
  {
    id: 3,
    name: "Corrida Leve",
    date: "2025-01-16",
    distance: 4.4,
    duration: 26,
    pace: 6.0,
    calories: 280,
    type: "Corrida",
  },
  {
    id: 4,
    name: "Corrida de Recuperação",
    date: "2025-01-15",
    distance: 3.8,
    duration: 24,
    pace: 6.3,
    calories: 240,
    type: "Recuperação",
  },
]

export function RecentWorkouts() {
  const getTypeColor = (type: string) => {
    switch (type) {
      case "Intervalado":
        return "bg-primary text-primary-foreground"
      case "Recuperação":
        return "bg-accent text-accent-foreground"
      default:
        return "bg-secondary text-secondary-foreground"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold font-serif">Treinos Recentes</h2>
          <p className="text-muted-foreground">Histórico dos seus últimos treinos</p>
        </div>
        <Button variant="outline" className="gap-2 bg-transparent">
          <Calendar className="w-4 h-4" />
          Ver Todos
        </Button>
      </div>

      <div className="grid gap-4">
        {recentWorkouts.map((workout) => (
          <Card key={workout.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-lg">{workout.name}</h3>
                    <Badge className={getTypeColor(workout.type)}>{workout.type}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {new Date(workout.date).toLocaleDateString("pt-BR")}
                  </p>
                </div>
                <Button variant="ghost" size="sm">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-primary" />
                  <div>
                    <div className="font-medium">{workout.distance}km</div>
                    <div className="text-xs text-muted-foreground">Distância</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-accent" />
                  <div>
                    <div className="font-medium">{workout.duration}min</div>
                    <div className="text-xs text-muted-foreground">Tempo</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-primary" />
                  <div>
                    <div className="font-medium">{workout.pace}'</div>
                    <div className="text-xs text-muted-foreground">Ritmo/km</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-accent rounded-full"></div>
                  <div>
                    <div className="font-medium">{workout.calories}</div>
                    <div className="text-xs text-muted-foreground">Calorias</div>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <Play className="w-3 h-3" />
                  Repetir Treino
                </Button>
                <Button variant="ghost" size="sm">
                  Ver Detalhes
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
