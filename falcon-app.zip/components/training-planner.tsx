"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Plus, Calendar, Clock, MapPin, Target, Trash2 } from "lucide-react"

interface TrainingSession {
  id: string
  name: string
  type: "easy" | "tempo" | "interval" | "long" | "recovery" | "strength"
  duration: number // em minutos
  distance?: number // em km
  intensity: "low" | "medium" | "high"
  description: string
  warmup?: string
  cooldown?: string
}

interface TrainingPlan {
  id: string
  name: string
  description: string
  duration: number // em semanas
  level: "beginner" | "intermediate" | "advanced"
  goal: string
  sessions: TrainingSession[]
  createdAt: Date
  isActive: boolean
}

interface TrainingPlannerProps {
  onBack: () => void
}

export default function TrainingPlanner({ onBack }: TrainingPlannerProps) {
  const [plans, setPlans] = useState<TrainingPlan[]>([])
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [showSessionDialog, setShowSessionDialog] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null)
  const [newPlan, setNewPlan] = useState({
    name: "",
    description: "",
    duration: 4,
    level: "beginner" as TrainingPlan["level"],
    goal: "",
  })
  const [newSession, setNewSession] = useState({
    name: "",
    type: "easy" as TrainingSession["type"],
    duration: 30,
    distance: 0,
    intensity: "medium" as TrainingSession["intensity"],
    description: "",
    warmup: "",
    cooldown: "",
  })

  useEffect(() => {
    loadPlans()
  }, [])

  const loadPlans = () => {
    const stored = localStorage.getItem("falcon-training-plans")
    if (stored) {
      const parsedPlans = JSON.parse(stored).map((plan: any) => ({
        ...plan,
        createdAt: new Date(plan.createdAt),
      }))
      setPlans(parsedPlans)
    }
  }

  const savePlans = (updatedPlans: TrainingPlan[]) => {
    localStorage.setItem("falcon-training-plans", JSON.stringify(updatedPlans))
    setPlans(updatedPlans)
  }

  const createPlan = () => {
    if (!newPlan.name) return

    const plan: TrainingPlan = {
      id: Date.now().toString(),
      name: newPlan.name,
      description: newPlan.description,
      duration: newPlan.duration,
      level: newPlan.level,
      goal: newPlan.goal,
      sessions: [],
      createdAt: new Date(),
      isActive: true,
    }

    const updatedPlans = [...plans, plan]
    savePlans(updatedPlans)
    setShowCreateDialog(false)
    setNewPlan({
      name: "",
      description: "",
      duration: 4,
      level: "beginner",
      goal: "",
    })
  }

  const addSession = () => {
    if (!selectedPlan || !newSession.name) return

    const session: TrainingSession = {
      id: Date.now().toString(),
      name: newSession.name,
      type: newSession.type,
      duration: newSession.duration,
      distance: newSession.distance || undefined,
      intensity: newSession.intensity,
      description: newSession.description,
      warmup: newSession.warmup || undefined,
      cooldown: newSession.cooldown || undefined,
    }

    const updatedPlans = plans.map((plan) =>
      plan.id === selectedPlan ? { ...plan, sessions: [...plan.sessions, session] } : plan,
    )

    savePlans(updatedPlans)
    setShowSessionDialog(false)
    setNewSession({
      name: "",
      type: "easy",
      duration: 30,
      distance: 0,
      intensity: "medium",
      description: "",
      warmup: "",
      cooldown: "",
    })
  }

  const deletePlan = (planId: string) => {
    const updatedPlans = plans.filter((plan) => plan.id !== planId)
    savePlans(updatedPlans)
  }

  const deleteSession = (planId: string, sessionId: string) => {
    const updatedPlans = plans.map((plan) =>
      plan.id === planId ? { ...plan, sessions: plan.sessions.filter((session) => session.id !== sessionId) } : plan,
    )
    savePlans(updatedPlans)
  }

  const getTypeColor = (type: TrainingSession["type"]) => {
    switch (type) {
      case "easy":
        return "bg-green-500"
      case "tempo":
        return "bg-yellow-500"
      case "interval":
        return "bg-red-500"
      case "long":
        return "bg-blue-500"
      case "recovery":
        return "bg-gray-500"
      case "strength":
        return "bg-purple-500"
    }
  }

  const getTypeLabel = (type: TrainingSession["type"]) => {
    switch (type) {
      case "easy":
        return "Leve"
      case "tempo":
        return "Tempo"
      case "interval":
        return "Intervalado"
      case "long":
        return "Longo"
      case "recovery":
        return "Recuperação"
      case "strength":
        return "Força"
    }
  }

  const getLevelLabel = (level: TrainingPlan["level"]) => {
    switch (level) {
      case "beginner":
        return "Iniciante"
      case "intermediate":
        return "Intermediário"
      case "advanced":
        return "Avançado"
    }
  }

  const getIntensityLabel = (intensity: TrainingSession["intensity"]) => {
    switch (intensity) {
      case "low":
        return "Baixa"
      case "medium":
        return "Média"
      case "high":
        return "Alta"
    }
  }

  return (
    <div className="min-h-screen bg-background p-4 space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={onBack}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="font-serif text-2xl font-bold text-primary">Planilhas de Treino</h1>
          <p className="text-muted-foreground">Crie e gerencie seus planos de treinamento</p>
        </div>
      </div>

      <div className="flex justify-between items-center">
        <div className="text-sm text-muted-foreground">{plans.length} planilhas criadas</div>
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Nova Planilha
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Criar Nova Planilha</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="plan-name">Nome da Planilha</Label>
                <Input
                  id="plan-name"
                  value={newPlan.name}
                  onChange={(e) => setNewPlan({ ...newPlan, name: e.target.value })}
                  placeholder="Ex: Preparação para 10K"
                />
              </div>
              <div>
                <Label htmlFor="plan-description">Descrição</Label>
                <Textarea
                  id="plan-description"
                  value={newPlan.description}
                  onChange={(e) => setNewPlan({ ...newPlan, description: e.target.value })}
                  placeholder="Descreva o objetivo desta planilha..."
                />
              </div>
              <div>
                <Label htmlFor="plan-duration">Duração (semanas)</Label>
                <Input
                  id="plan-duration"
                  type="number"
                  value={newPlan.duration}
                  onChange={(e) => setNewPlan({ ...newPlan, duration: Number.parseInt(e.target.value) || 4 })}
                />
              </div>
              <div>
                <Label htmlFor="plan-level">Nível</Label>
                <Select
                  value={newPlan.level}
                  onValueChange={(value: TrainingPlan["level"]) => setNewPlan({ ...newPlan, level: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="beginner">Iniciante</SelectItem>
                    <SelectItem value="intermediate">Intermediário</SelectItem>
                    <SelectItem value="advanced">Avançado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="plan-goal">Objetivo</Label>
                <Input
                  id="plan-goal"
                  value={newPlan.goal}
                  onChange={(e) => setNewPlan({ ...newPlan, goal: e.target.value })}
                  placeholder="Ex: Correr 10K em 45 minutos"
                />
              </div>
              <Button onClick={createPlan} className="w-full">
                Criar Planilha
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {plans.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Nenhuma planilha criada</p>
              <p className="text-sm text-muted-foreground">Crie sua primeira planilha de treino!</p>
            </CardContent>
          </Card>
        ) : (
          plans.map((plan) => (
            <Card key={plan.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">{plan.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">{plan.description}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">{getLevelLabel(plan.level)}</Badge>
                    <Badge variant="outline">{plan.duration} semanas</Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {plan.goal && (
                  <div className="flex items-center gap-2 text-sm">
                    <Target className="h-4 w-4 text-primary" />
                    <span>{plan.goal}</span>
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">{plan.sessions.length} sessões de treino</span>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedPlan(plan.id)
                        setShowSessionDialog(true)
                      }}
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Adicionar Sessão
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => deletePlan(plan.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {plan.sessions.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="font-medium text-sm">Sessões de Treino:</h4>
                    {plan.sessions.map((session) => (
                      <div key={session.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className={`w-3 h-3 rounded-full ${getTypeColor(session.type)}`} />
                          <div>
                            <p className="font-medium text-sm">{session.name}</p>
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {session.duration}min
                              </span>
                              {session.distance && (
                                <span className="flex items-center gap-1">
                                  <MapPin className="h-3 w-3" />
                                  {session.distance}km
                                </span>
                              )}
                              <Badge variant="outline" className="text-xs">
                                {getTypeLabel(session.type)}
                              </Badge>
                              <Badge variant="outline" className="text-xs">
                                {getIntensityLabel(session.intensity)}
                              </Badge>
                            </div>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm" onClick={() => deleteSession(plan.id, session.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>

      <Dialog open={showSessionDialog} onOpenChange={setShowSessionDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Adicionar Sessão de Treino</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="session-name">Nome da Sessão</Label>
                <Input
                  id="session-name"
                  value={newSession.name}
                  onChange={(e) => setNewSession({ ...newSession, name: e.target.value })}
                  placeholder="Ex: Corrida Intervalada"
                />
              </div>
              <div>
                <Label htmlFor="session-type">Tipo</Label>
                <Select
                  value={newSession.type}
                  onValueChange={(value: TrainingSession["type"]) => setNewSession({ ...newSession, type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="easy">Leve</SelectItem>
                    <SelectItem value="tempo">Tempo</SelectItem>
                    <SelectItem value="interval">Intervalado</SelectItem>
                    <SelectItem value="long">Longo</SelectItem>
                    <SelectItem value="recovery">Recuperação</SelectItem>
                    <SelectItem value="strength">Força</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="session-duration">Duração (min)</Label>
                <Input
                  id="session-duration"
                  type="number"
                  value={newSession.duration}
                  onChange={(e) => setNewSession({ ...newSession, duration: Number.parseInt(e.target.value) || 30 })}
                />
              </div>
              <div>
                <Label htmlFor="session-distance">Distância (km)</Label>
                <Input
                  id="session-distance"
                  type="number"
                  step="0.1"
                  value={newSession.distance}
                  onChange={(e) => setNewSession({ ...newSession, distance: Number.parseFloat(e.target.value) || 0 })}
                />
              </div>
              <div>
                <Label htmlFor="session-intensity">Intensidade</Label>
                <Select
                  value={newSession.intensity}
                  onValueChange={(value: TrainingSession["intensity"]) =>
                    setNewSession({ ...newSession, intensity: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Baixa</SelectItem>
                    <SelectItem value="medium">Média</SelectItem>
                    <SelectItem value="high">Alta</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="session-description">Descrição</Label>
              <Textarea
                id="session-description"
                value={newSession.description}
                onChange={(e) => setNewSession({ ...newSession, description: e.target.value })}
                placeholder="Descreva o treino em detalhes..."
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="session-warmup">Aquecimento</Label>
                <Textarea
                  id="session-warmup"
                  value={newSession.warmup}
                  onChange={(e) => setNewSession({ ...newSession, warmup: e.target.value })}
                  placeholder="Rotina de aquecimento..."
                />
              </div>
              <div>
                <Label htmlFor="session-cooldown">Desaquecimento</Label>
                <Textarea
                  id="session-cooldown"
                  value={newSession.cooldown}
                  onChange={(e) => setNewSession({ ...newSession, cooldown: e.target.value })}
                  placeholder="Rotina de desaquecimento..."
                />
              </div>
            </div>

            <Button onClick={addSession} className="w-full">
              Adicionar Sessão
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
