"use client"

import { useEffect, useRef } from "react"
import { MapPin } from "lucide-react"

interface Position {
  latitude: number
  longitude: number
  timestamp: number
}

interface GPSMapProps {
  currentPosition: Position | null
  positions: Position[]
  isTracking: boolean
}

export function GPSMap({ currentPosition, positions, isTracking }: GPSMapProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<any | null>(null)
  const pathRef = useRef<any | null>(null)
  const markerRef = useRef<any | null>(null)

  useEffect(() => {
    // Initialize Google Maps when component mounts
    const initMap = () => {
      if (!mapRef.current || !window.google) return

      const defaultCenter = currentPosition
        ? { lat: currentPosition.latitude, lng: currentPosition.longitude }
        : { lat: -23.5505, lng: -46.6333 } // São Paulo default

      mapInstanceRef.current = new window.google.maps.Map(mapRef.current, {
        zoom: 16,
        center: defaultCenter,
        mapTypeId: window.google.maps.MapTypeId.ROADMAP,
        styles: [
          {
            featureType: "poi",
            elementType: "labels",
            stylers: [{ visibility: "off" }],
          },
        ],
      })

      // Initialize polyline for route
      pathRef.current = new window.google.maps.Polyline({
        path: [],
        geodesic: true,
        strokeColor: "#dc2626",
        strokeOpacity: 1.0,
        strokeWeight: 4,
      })
      pathRef.current.setMap(mapInstanceRef.current)

      // Initialize marker for current position
      markerRef.current = new window.google.maps.Marker({
        position: defaultCenter,
        map: mapInstanceRef.current,
        title: "Posição Atual",
        icon: {
          path: window.google.maps.SymbolPath.CIRCLE,
          scale: 8,
          fillColor: "#dc2626",
          fillOpacity: 1,
          strokeColor: "#ffffff",
          strokeWeight: 2,
        },
      })
    }

    // Load Google Maps script if not already loaded
    if (!window.google) {
      const script = document.createElement("script")
      script.src = `https://maps.googleapis.com/maps/api/js?key=${process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY}&libraries=geometry`
      script.async = true
      script.defer = true
      script.onload = initMap
      document.head.appendChild(script)
    } else {
      initMap()
    }
  }, [currentPosition])

  useEffect(() => {
    // Update map when current position changes
    if (currentPosition && mapInstanceRef.current && markerRef.current) {
      const newPosition = { lat: currentPosition.latitude, lng: currentPosition.longitude }

      markerRef.current.setPosition(newPosition)
      mapInstanceRef.current.setCenter(newPosition)

      // Update path
      if (pathRef.current && positions.length > 1) {
        const path = positions.map((pos) => ({ lat: pos.latitude, lng: pos.longitude }))
        pathRef.current.setPath(path)
      }
    }
  }, [currentPosition, positions])

  if (!isTracking && positions.length === 0) {
    return (
      <div className="h-48 bg-muted rounded-lg flex items-center justify-center border-2 border-dashed border-border">
        <div className="text-center text-muted-foreground">
          <MapPin className="w-12 h-12 mx-auto mb-2 opacity-50" />
          <p>Mapa GPS aparecerá aqui</p>
          <p className="text-sm">durante o rastreamento</p>
        </div>
      </div>
    )
  }

  return (
    <div className="relative">
      <div ref={mapRef} className="h-48 w-full rounded-lg" />
      {isTracking && (
        <div className="absolute top-2 right-2 bg-primary text-primary-foreground px-2 py-1 rounded text-xs font-medium">
          GPS Ativo
        </div>
      )}
    </div>
  )
}
