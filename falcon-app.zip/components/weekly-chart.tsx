"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, LineChart, Line } from "recharts"
import { TrendingUp } from "lucide-react"

const weeklyData = [
  { day: "Seg", distance: 5.2, pace: 6.1 },
  { day: "Ter", distance: 0, pace: 0 },
  { day: "Qua", distance: 3.8, pace: 6.3 },
  { day: "Qui", distance: 6.1, pace: 5.9 },
  { day: "Sex", distance: 0, pace: 0 },
  { day: "Sáb", distance: 4.4, pace: 6.0 },
  { day: "Dom", distance: 8.2, pace: 5.8 },
]

export function WeeklyChart() {
  return (
    <div className="grid md:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 font-serif">
            <TrendingUp className="w-5 h-5 text-primary" />
            Distância Semanal
          </CardTitle>
          <CardDescription>Quilômetros percorridos por dia</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              distance: {
                label: "Distância (km)",
                color: "hsl(var(--primary))",
              },
            }}
            className="h-[200px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyData}>
                <XAxis dataKey="day" />
                <YAxis />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="distance" fill="var(--color-primary)" radius={4} />
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 font-serif">
            <TrendingUp className="w-5 h-5 text-accent" />
            Evolução do Ritmo
          </CardTitle>
          <CardDescription>Ritmo médio por treino (min/km)</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              pace: {
                label: "Ritmo (min/km)",
                color: "hsl(var(--accent))",
              },
            }}
            className="h-[200px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={weeklyData.filter((d) => d.pace > 0)}>
                <XAxis dataKey="day" />
                <YAxis domain={[5.5, 6.5]} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Line
                  type="monotone"
                  dataKey="pace"
                  stroke="var(--color-accent)"
                  strokeWidth={3}
                  dot={{ fill: "var(--color-accent)", strokeWidth: 2, r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>
    </div>
  )
}
