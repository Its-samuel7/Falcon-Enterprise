"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Play, Clock, Eye, ExternalLink } from "lucide-react"
import Image from "next/image"

interface Video {
  id: number
  title: string
  instructor: string
  duration: string
  views: string
  thumbnail: string
  url: string
  category: string
}

interface VideoCardProps {
  video: Video
}

export function VideoCard({ video }: VideoCardProps) {
  return (
    <Card className="hover:shadow-lg transition-shadow group">
      <CardContent className="p-4">
        <div className="relative mb-4">
          <Image
            src={video.thumbnail || "/placeholder.svg"}
            alt={video.title}
            width={200}
            height={120}
            className="w-full h-32 object-cover rounded-lg"
          />
          <div className="absolute inset-0 bg-black/20 rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
              <Play className="w-6 h-6 text-primary-foreground ml-1" />
            </div>
          </div>
          <Badge className="absolute bottom-2 right-2 bg-black/70 text-white">{video.duration}</Badge>
        </div>

        <div className="space-y-3">
          <div>
            <h3 className="font-semibold text-lg line-clamp-2 group-hover:text-primary transition-colors">
              {video.title}
            </h3>
            <p className="text-sm text-muted-foreground">por {video.instructor}</p>
          </div>

          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {video.duration}
            </div>
            <div className="flex items-center gap-1">
              <Eye className="w-3 h-3" />
              {video.views} visualizações
            </div>
          </div>

          <Button className="w-full gap-2">
            <ExternalLink className="w-4 h-4" />
            Assistir Vídeo
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
