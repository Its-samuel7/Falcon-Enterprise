"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, AreaChart, Area } from "recharts"
import { TrendingUp, TrendingDown, Activity, Target } from "lucide-react"

const performanceData = [
  { month: "Set", distance: 45, pace: 6.8, consistency: 60 },
  { month: "Out", distance: 62, pace: 6.5, consistency: 75 },
  { month: "Nov", distance: 71, pace: 6.2, consistency: 80 },
  { month: "Dez", distance: 85, pace: 6.0, consistency: 85 },
  { month: "Jan", distance: 78, pace: 5.8, consistency: 90 },
]

const paceData = [
  { week: "Sem 1", pace: 6.2 },
  { week: "Sem 2", pace: 6.1 },
  { week: "Sem 3", pace: 5.9 },
  { week: "Sem 4", pace: 5.8 },
]

export function PerformanceMetrics() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold font-serif">Análise de Performance</h2>
        <p className="text-muted-foreground">Insights detalhados sobre seu progresso atlético</p>
      </div>

      {/* Key Performance Indicators */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <TrendingUp className="w-6 h-6 text-green-500 mx-auto mb-2" />
            <div className="text-2xl font-bold text-green-500">+12%</div>
            <div className="text-sm text-muted-foreground">Melhoria no ritmo</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Activity className="w-6 h-6 text-primary mx-auto mb-2" />
            <div className="text-2xl font-bold">90%</div>
            <div className="text-sm text-muted-foreground">Consistência</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Target className="w-6 h-6 text-accent mx-auto mb-2" />
            <div className="text-2xl font-bold">85%</div>
            <div className="text-sm text-muted-foreground">Metas atingidas</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <TrendingUp className="w-6 h-6 text-green-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">+23km</div>
            <div className="text-sm text-muted-foreground">vs mês anterior</div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Charts */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 font-serif">
              <TrendingUp className="w-5 h-5 text-primary" />
              Evolução Mensal
            </CardTitle>
            <CardDescription>Distância percorrida por mês</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                distance: {
                  label: "Distância (km)",
                  color: "hsl(var(--primary))",
                },
              }}
              className="h-[250px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={performanceData}>
                  <XAxis dataKey="month" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Area
                    type="monotone"
                    dataKey="distance"
                    stroke="var(--color-primary)"
                    fill="var(--color-primary)"
                    fillOpacity={0.2}
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 font-serif">
              <TrendingDown className="w-5 h-5 text-accent" />
              Melhoria do Ritmo
            </CardTitle>
            <CardDescription>Ritmo médio nas últimas semanas</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                pace: {
                  label: "Ritmo (min/km)",
                  color: "hsl(var(--accent))",
                },
              }}
              className="h-[250px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={paceData}>
                  <XAxis dataKey="week" />
                  <YAxis domain={[5.5, 6.5]} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line
                    type="monotone"
                    dataKey="pace"
                    stroke="var(--color-accent)"
                    strokeWidth={3}
                    dot={{ fill: "var(--color-accent)", strokeWidth: 2, r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>

      {/* Insights and Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="font-serif">Insights e Recomendações</CardTitle>
          <CardDescription>Análise personalizada do seu desempenho</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="border-l-4 border-green-500 pl-4 bg-green-50 dark:bg-green-950/20 p-3 rounded-r">
            <h4 className="font-medium text-green-700 dark:text-green-400">Excelente Progresso!</h4>
            <p className="text-sm text-green-600 dark:text-green-300">
              Seu ritmo melhorou 12% nos últimos 3 meses. Continue com os treinos intervalados.
            </p>
          </div>
          <div className="border-l-4 border-accent pl-4 bg-accent/10 p-3 rounded-r">
            <h4 className="font-medium">Oportunidade de Melhoria</h4>
            <p className="text-sm text-muted-foreground">
              Considere adicionar mais treinos de resistência para aumentar sua base aeróbica.
            </p>
          </div>
          <div className="border-l-4 border-primary pl-4 bg-primary/10 p-3 rounded-r">
            <h4 className="font-medium">Meta Recomendada</h4>
            <p className="text-sm text-muted-foreground">
              Com base no seu progresso, sugerimos uma meta de 110km para o próximo mês.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
