"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, MessageCircle, Heart, Share2, MapPin, Clock, TrendingUp, Plus, Search, Star } from "lucide-react"

interface Post {
  id: string
  user: {
    name: string
    avatar: string
    level: string
  }
  content: string
  type: "run" | "achievement" | "challenge" | "motivation"
  data?: {
    distance?: number
    time?: number
    pace?: string
    route?: string
  }
  likes: number
  comments: number
  timestamp: Date
  liked: boolean
}

interface Club {
  id: string
  name: string
  description: string
  members: number
  category: string
  location: string
  isJoined: boolean
  avatar: string
}

interface CommunityProps {
  onBack: () => void
}

export default function Community({ onBack }: CommunityProps) {
  const [activeTab, setActiveTab] = useState("feed")
  const [searchQuery, setSearchQuery] = useState("")

  const posts: Post[] = [
    {
      id: "1",
      user: {
        name: "Ana Silva",
        avatar: "/placeholder.svg?height=40&width=40",
        level: "Intermediário",
      },
      content: "Acabei de completar minha primeira 10K! 🏃‍♀️ Que sensação incrível!",
      type: "achievement",
      data: {
        distance: 10.2,
        time: 3180, // 53 minutes
        pace: "5:12",
      },
      likes: 24,
      comments: 8,
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      liked: false,
    },
    {
      id: "2",
      user: {
        name: "Carlos Mendes",
        avatar: "/placeholder.svg?height=40&width=40",
        level: "Avançado",
      },
      content: "Treino intervalado hoje! 8x400m. Quem mais está treinando velocidade?",
      type: "run",
      data: {
        distance: 6.5,
        time: 1800,
        pace: "4:38",
      },
      likes: 15,
      comments: 12,
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
      liked: true,
    },
    {
      id: "3",
      user: {
        name: "Maria Santos",
        avatar: "/placeholder.svg?height=40&width=40",
        level: "Iniciante",
      },
      content: "Conquistei a medalha 'Primeira 5K'! Obrigada a todos pelo apoio! 🏅",
      type: "achievement",
      likes: 31,
      comments: 15,
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
      liked: false,
    },
  ]

  const clubs: Club[] = [
    {
      id: "1",
      name: "Corredores de São Paulo",
      description: "Grupo para corredores da capital paulista",
      members: 1247,
      category: "Regional",
      location: "São Paulo, SP",
      isJoined: true,
      avatar: "/placeholder.svg?height=50&width=50",
    },
    {
      id: "2",
      name: "Iniciantes na Corrida",
      description: "Apoio e dicas para quem está começando",
      members: 892,
      category: "Nível",
      location: "Nacional",
      isJoined: false,
      avatar: "/placeholder.svg?height=50&width=50",
    },
    {
      id: "3",
      name: "Maratonistas Brasil",
      description: "Para quem sonha com os 42km",
      members: 456,
      category: "Especialidade",
      location: "Nacional",
      isJoined: false,
      avatar: "/placeholder.svg?height=50&width=50",
    },
  ]

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    if (hours > 0) {
      return `${hours}h${minutes.toString().padStart(2, "0")}min`
    }
    return `${minutes}min`
  }

  const getTimeAgo = (date: Date) => {
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const hours = Math.floor(diff / (1000 * 60 * 60))

    if (hours < 1) return "Agora há pouco"
    if (hours === 1) return "1 hora atrás"
    return `${hours} horas atrás`
  }

  return (
    <div className="min-h-screen bg-background p-4 pb-20 space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={onBack}>
          ← Voltar
        </Button>
        <h1 className="font-serif text-2xl font-bold text-primary">Comunidade</h1>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="feed">Feed</TabsTrigger>
          <TabsTrigger value="clubs">Clubes</TabsTrigger>
          <TabsTrigger value="mentors">Mentores</TabsTrigger>
        </TabsList>

        <TabsContent value="feed" className="space-y-4 mt-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarFallback>EU</AvatarFallback>
                </Avatar>
                <Input placeholder="Compartilhe sua conquista..." className="flex-1" />
                <Button size="sm">
                  <Share2 className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {posts.map((post) => (
            <Card key={post.id}>
              <CardContent className="p-4 space-y-4">
                <div className="flex items-start gap-3">
                  <Avatar>
                    <AvatarImage src={post.user.avatar || "/placeholder.svg"} />
                    <AvatarFallback>
                      {post.user.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium">{post.user.name}</span>
                      <Badge variant="secondary" className="text-xs">
                        {post.user.level}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{getTimeAgo(post.timestamp)}</p>
                  </div>
                </div>

                <p>{post.content}</p>

                {post.data && (
                  <Card className="bg-muted/50">
                    <CardContent className="p-3">
                      <div className="flex items-center justify-between text-sm">
                        {post.data.distance && (
                          <div className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {post.data.distance}km
                          </div>
                        )}
                        {post.data.time && (
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {formatTime(post.data.time)}
                          </div>
                        )}
                        {post.data.pace && (
                          <div className="flex items-center gap-1">
                            <TrendingUp className="h-3 w-3" />
                            {post.data.pace}/km
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )}

                <div className="flex items-center justify-between pt-2 border-t">
                  <Button variant="ghost" size="sm" className={post.liked ? "text-red-500" : ""}>
                    <Heart className={`h-4 w-4 mr-1 ${post.liked ? "fill-current" : ""}`} />
                    {post.likes}
                  </Button>
                  <Button variant="ghost" size="sm">
                    <MessageCircle className="h-4 w-4 mr-1" />
                    {post.comments}
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Share2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="clubs" className="space-y-4 mt-6">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar clubes..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button>
              <Plus className="h-4 w-4 mr-1" />
              Criar
            </Button>
          </div>

          {clubs.map((club) => (
            <Card key={club.id}>
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={club.avatar || "/placeholder.svg"} />
                    <AvatarFallback>
                      {club.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-medium">{club.name}</h3>
                      {club.isJoined && (
                        <Badge variant="secondary" className="text-xs">
                          Membro
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{club.description}</p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Users className="h-3 w-3" />
                        {club.members} membros
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {club.location}
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {club.category}
                      </Badge>
                    </div>
                  </div>
                </div>
                <div className="mt-3 pt-3 border-t">
                  {club.isJoined ? (
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                        <MessageCircle className="h-3 w-3 mr-1" />
                        Chat
                      </Button>
                      <Button variant="outline" size="sm">
                        Sair
                      </Button>
                    </div>
                  ) : (
                    <Button size="sm" className="w-full">
                      Participar
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="mentors" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="h-5 w-5 text-primary" />
                Mentores Disponíveis
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                {
                  name: "Prof. João Silva",
                  specialty: "Técnica de Corrida",
                  experience: "15 anos",
                  rating: 4.9,
                  sessions: 234,
                },
                {
                  name: "Dra. Ana Costa",
                  specialty: "Nutrição Esportiva",
                  experience: "8 anos",
                  rating: 4.8,
                  sessions: 156,
                },
                {
                  name: "Carlos Oliveira",
                  specialty: "Preparação Física",
                  experience: "12 anos",
                  rating: 4.9,
                  sessions: 189,
                },
              ].map((mentor, index) => (
                <Card key={index} className="bg-muted/50">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <Avatar>
                        <AvatarFallback>
                          {mentor.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h4 className="font-medium">{mentor.name}</h4>
                        <p className="text-sm text-muted-foreground">{mentor.specialty}</p>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground mt-2">
                          <span>{mentor.experience} experiência</span>
                          <div className="flex items-center gap-1">
                            <Star className="h-3 w-3 fill-current text-yellow-500" />
                            {mentor.rating}
                          </div>
                          <span>{mentor.sessions} sessões</span>
                        </div>
                      </div>
                    </div>
                    <Button size="sm" className="w-full mt-3">
                      <MessageCircle className="h-3 w-3 mr-1" />
                      Iniciar Conversa
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
