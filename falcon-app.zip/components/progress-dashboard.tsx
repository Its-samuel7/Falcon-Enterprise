"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Target, TrendingUp, Calendar, Award, Flame, CheckCircle, ArrowLeft } from "lucide-react"

interface SavedRun {
  id: string
  name: string
  date: Date
  distance: number
  duration: number
  pace: number
  elevationGain: number
}

interface ProgressDashboardProps {
  savedRuns: SavedRun[]
  onBack: () => void
}

export default function ProgressDashboard({ savedRuns, onBack }: ProgressDashboardProps) {
  const [weeklyGoal] = useState(25) // km
  const [monthlyGoal] = useState(100) // km

  const getWeeklyStats = () => {
    const oneWeekAgo = new Date()
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7)

    const weeklyRuns = savedRuns.filter((run) => new Date(run.date) >= oneWeekAgo)
    const totalDistance = weeklyRuns.reduce((sum, run) => sum + run.distance, 0)
    const totalDuration = weeklyRuns.reduce((sum, run) => sum + run.duration, 0)

    return {
      runs: weeklyRuns.length,
      distance: totalDistance,
      duration: totalDuration,
      avgPace: weeklyRuns.length > 0 ? totalDuration / 60 / totalDistance : 0,
    }
  }

  const getMonthlyStats = () => {
    const oneMonthAgo = new Date()
    oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1)

    const monthlyRuns = savedRuns.filter((run) => new Date(run.date) >= oneMonthAgo)
    const totalDistance = monthlyRuns.reduce((sum, run) => sum + run.distance, 0)

    return {
      runs: monthlyRuns.length,
      distance: totalDistance,
    }
  }

  const getCurrentStreak = () => {
    if (savedRuns.length === 0) return 0

    const sortedRuns = [...savedRuns].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    let streak = 0
    let currentDate = new Date()
    currentDate.setHours(0, 0, 0, 0)

    for (let i = 0; i < sortedRuns.length; i++) {
      const runDate = new Date(sortedRuns[i].date)
      runDate.setHours(0, 0, 0, 0)

      const daysDiff = Math.floor((currentDate.getTime() - runDate.getTime()) / (1000 * 60 * 60 * 24))

      if (daysDiff === streak || (streak === 0 && daysDiff <= 1)) {
        streak++
        currentDate = new Date(runDate)
      } else {
        break
      }
    }

    return streak
  }

  const formatDistance = (km: number) => {
    if (km < 1) {
      return (km * 1000).toFixed(0) + "m"
    }
    return km.toFixed(1) + "km"
  }

  const formatPace = (pace: number) => {
    if (pace === 0 || !isFinite(pace)) return "--:--"
    const mins = Math.floor(pace)
    const secs = Math.floor((pace - mins) * 60)
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const weeklyStats = getWeeklyStats()
  const monthlyStats = getMonthlyStats()
  const currentStreak = getCurrentStreak()

  const weeklyProgress = (weeklyStats.distance / weeklyGoal) * 100
  const monthlyProgress = (monthlyStats.distance / monthlyGoal) * 100

  return (
    <div className="min-h-screen bg-background p-4 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-serif text-2xl font-bold text-primary">Dashboard de Progresso</h1>
          <p className="text-muted-foreground">Acompanhe suas metas e conquistas</p>
        </div>
        <Button variant="outline" size="sm" onClick={onBack}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar
        </Button>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="goals">Metas</TabsTrigger>
          <TabsTrigger value="achievements">Conquistas</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  Estatísticas Gerais
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-primary">{savedRuns.length}</p>
                    <p className="text-xs text-muted-foreground">Total de Corridas</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-primary">
                      {formatDistance(savedRuns.reduce((sum, run) => sum + run.distance, 0))}
                    </p>
                    <p className="text-xs text-muted-foreground">Distância Total</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-primary">{currentStreak}</p>
                    <p className="text-xs text-muted-foreground">Sequência Atual</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-primary">{weeklyStats.runs}</p>
                    <p className="text-xs text-muted-foreground">Corridas esta Semana</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Flame className="h-5 w-5 text-primary" />
                  Desempenho Recente
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Ritmo médio semanal</span>
                  <span className="font-semibold">{formatPace(weeklyStats.avgPace)}/km</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Distância esta semana</span>
                  <span className="font-semibold">{formatDistance(weeklyStats.distance)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Corridas este mês</span>
                  <span className="font-semibold">{monthlyStats.runs}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="goals" className="space-y-4">
          <div className="grid gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Target className="h-5 w-5 text-primary" />
                  Meta Semanal
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Distância: {formatDistance(weeklyStats.distance)}</span>
                    <span>{formatDistance(weeklyGoal)} meta</span>
                  </div>
                  <Progress value={Math.min(weeklyProgress, 100)} className="h-2" />
                  <p className="text-xs text-muted-foreground text-center">
                    {weeklyProgress.toFixed(0)}% da meta semanal concluída
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Calendar className="h-5 w-5 text-primary" />
                  Meta Mensal
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Distância: {formatDistance(monthlyStats.distance)}</span>
                    <span>{formatDistance(monthlyGoal)} meta</span>
                  </div>
                  <Progress value={Math.min(monthlyProgress, 100)} className="h-2" />
                  <p className="text-xs text-muted-foreground text-center">
                    {monthlyProgress.toFixed(0)}% da meta mensal concluída
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="achievements" className="space-y-4">
          <div className="grid gap-3">
            <Card className={savedRuns.length >= 1 ? "border-primary" : ""}>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="text-2xl">🏃</div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">Primeira Corrida</h3>
                      {savedRuns.length >= 1 && <CheckCircle className="h-4 w-4 text-primary" />}
                    </div>
                    <p className="text-sm text-muted-foreground">Complete sua primeira corrida</p>
                  </div>
                  {savedRuns.length >= 1 && (
                    <Badge variant="secondary" className="bg-primary/10 text-primary">
                      Conquistado
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className={savedRuns.some((run) => run.distance >= 5) ? "border-primary" : ""}>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="text-2xl">🎯</div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">5K Runner</h3>
                      {savedRuns.some((run) => run.distance >= 5) && <CheckCircle className="h-4 w-4 text-primary" />}
                    </div>
                    <p className="text-sm text-muted-foreground">Corra 5km em uma única sessão</p>
                  </div>
                  {savedRuns.some((run) => run.distance >= 5) && (
                    <Badge variant="secondary" className="bg-primary/10 text-primary">
                      Conquistado
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className={currentStreak >= 7 ? "border-primary" : ""}>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="text-2xl">🔥</div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">Sequência de 7 dias</h3>
                      {currentStreak >= 7 && <CheckCircle className="h-4 w-4 text-primary" />}
                    </div>
                    <p className="text-sm text-muted-foreground">Corra por 7 dias consecutivos</p>
                  </div>
                  {currentStreak >= 7 && (
                    <Badge variant="secondary" className="bg-primary/10 text-primary">
                      Conquistado
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 text-center">
                <Award className="h-8 w-8 text-primary mx-auto mb-2" />
                <p className="font-semibold">
                  {
                    [savedRuns.length >= 1, savedRuns.some((run) => run.distance >= 5), currentStreak >= 7].filter(
                      Boolean,
                    ).length
                  }{" "}
                  de 3 conquistas
                </p>
                <p className="text-sm text-muted-foreground">Continue correndo para desbloquear mais!</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
