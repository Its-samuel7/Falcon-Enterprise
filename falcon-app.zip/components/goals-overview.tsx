"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Plus, Calendar, TrendingUp, Clock, MapPin } from "lucide-react"

const goals = [
  {
    id: 1,
    title: "Correr 100km este mês",
    description: "Meta mensal de distância",
    current: 78.2,
    target: 100,
    unit: "km",
    deadline: "2025-01-31",
    status: "on-track",
    icon: MapPin,
  },
  {
    id: 2,
    title: "Melhorar ritmo para 5:30/km",
    description: "Meta de velocidade",
    current: 5.8,
    target: 5.5,
    unit: "min/km",
    deadline: "2025-02-15",
    status: "behind",
    icon: TrendingUp,
    isReverse: true, // Lower is better for pace
  },
  {
    id: 3,
    title: "Treinar 5x por semana",
    description: "Frequência de treinos",
    current: 4,
    target: 5,
    unit: "treinos",
    deadline: "Semanal",
    status: "on-track",
    icon: Calendar,
  },
  {
    id: 4,
    title: "Correr por 10 horas este mês",
    description: "Meta de tempo total",
    current: 8.2,
    target: 10,
    unit: "horas",
    deadline: "2025-01-31",
    status: "on-track",
    icon: Clock,
  },
]

export function GoalsOverview() {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-500 text-white"
      case "on-track":
        return "bg-primary text-primary-foreground"
      case "behind":
        return "bg-destructive text-destructive-foreground"
      default:
        return "bg-secondary text-secondary-foreground"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "completed":
        return "Concluída"
      case "on-track":
        return "No Prazo"
      case "behind":
        return "Atrasada"
      default:
        return "Pendente"
    }
  }

  const calculateProgress = (current: number, target: number, isReverse = false) => {
    if (isReverse) {
      // For pace, lower is better, so we calculate differently
      const improvement = Math.max(0, target - current)
      const maxImprovement = target * 0.2 // Assume 20% improvement is the range
      return Math.min(100, (improvement / maxImprovement) * 100)
    }
    return Math.min(100, (current / target) * 100)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold font-serif">Suas Metas</h2>
          <p className="text-muted-foreground">Acompanhe seu progresso e conquiste seus objetivos</p>
        </div>
        <Button className="gap-2">
          <Plus className="w-4 h-4" />
          Nova Meta
        </Button>
      </div>

      <div className="grid gap-6">
        {goals.map((goal) => {
          const IconComponent = goal.icon
          const progress = calculateProgress(goal.current, goal.target, goal.isReverse)

          return (
            <Card key={goal.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                      <IconComponent className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="font-serif">{goal.title}</CardTitle>
                      <CardDescription>{goal.description}</CardDescription>
                    </div>
                  </div>
                  <Badge className={getStatusColor(goal.status)}>{getStatusText(goal.status)}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>
                      {goal.current} {goal.unit} de {goal.target} {goal.unit}
                    </span>
                    <span className="text-accent font-medium">{Math.round(progress)}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Prazo: {goal.deadline}</span>
                    <span>
                      {goal.isReverse
                        ? `Faltam ${Math.max(0, goal.current - goal.target).toFixed(1)} ${goal.unit}`
                        : `Faltam ${Math.max(0, goal.target - goal.current).toFixed(1)} ${goal.unit}`}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
