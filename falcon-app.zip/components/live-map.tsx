"use client"

import { useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { MapPin, Navigation } from "lucide-react"

interface GPSCoordinate {
  latitude: number
  longitude: number
  timestamp: number
  accuracy: number
  altitude?: number
}

interface LiveMapProps {
  coordinates: GPSCoordinate[]
  currentLocation: GPSCoordinate | null
  isRunning: boolean
}

export default function LiveMap({ coordinates, currentLocation, isRunning }: LiveMapProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<any>(null)
  const routeLayerRef = useRef<any>(null)
  const currentMarkerRef = useRef<any>(null)

  useEffect(() => {
    if (typeof window === "undefined") return

    // Dynamically import Leaflet to avoid SSR issues
    import("leaflet").then((L) => {
      if (!mapRef.current || mapInstanceRef.current) return

      // Initialize map
      mapInstanceRef.current = L.map(mapRef.current).setView([0, 0], 16)

      // Add OpenStreetMap tiles
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "© OpenStreetMap contributors",
      }).addTo(mapInstanceRef.current)

      // Initialize route layer
      routeLayerRef.current = L.layerGroup().addTo(mapInstanceRef.current)
    })

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove()
        mapInstanceRef.current = null
      }
    }
  }, [])

  useEffect(() => {
    if (!mapInstanceRef.current || typeof window === "undefined") return

    import("leaflet").then((L) => {
      // Clear existing route and marker
      if (routeLayerRef.current) {
        routeLayerRef.current.clearLayers()
      }
      if (currentMarkerRef.current) {
        mapInstanceRef.current.removeLayer(currentMarkerRef.current)
      }

      // Update current location marker
      if (currentLocation) {
        const currentIcon = L.divIcon({
          className: "current-location-marker",
          html: `<div style="
            width: 20px; 
            height: 20px; 
            background: #dc2626; 
            border: 3px solid white; 
            border-radius: 50%; 
            box-shadow: 0 2px 4px rgba(0,0,0,0.3);
            ${isRunning ? "animation: pulse 2s infinite;" : ""}
          "></div>`,
          iconSize: [20, 20],
          iconAnchor: [10, 10],
        })

        currentMarkerRef.current = L.marker([currentLocation.latitude, currentLocation.longitude], {
          icon: currentIcon,
        }).addTo(mapInstanceRef.current)

        // Center map on current location
        mapInstanceRef.current.setView([currentLocation.latitude, currentLocation.longitude], 16)
      }

      // Draw route if we have coordinates
      if (coordinates.length > 1) {
        const routeCoords = coordinates.map((coord) => [coord.latitude, coord.longitude])

        // Draw the completed route in a different color
        const routeLine = L.polyline(routeCoords, {
          color: "#dc2626",
          weight: 4,
          opacity: 0.8,
          smoothFactor: 1,
        }).addTo(routeLayerRef.current)

        // Add start marker
        if (coordinates.length > 0) {
          const startIcon = L.divIcon({
            className: "start-marker",
            html: `<div style="
              width: 16px; 
              height: 16px; 
              background: #16a34a; 
              border: 2px solid white; 
              border-radius: 50%; 
              box-shadow: 0 1px 3px rgba(0,0,0,0.3);
            "></div>`,
            iconSize: [16, 16],
            iconAnchor: [8, 8],
          })

          L.marker([coordinates[0].latitude, coordinates[0].longitude], {
            icon: startIcon,
          }).addTo(routeLayerRef.current)
        }

        // Fit map to show entire route
        if (coordinates.length > 1) {
          const bounds = L.latLngBounds(routeCoords)
          mapInstanceRef.current.fitBounds(bounds, { padding: [20, 20] })
        }
      }
    })
  }, [coordinates, currentLocation, isRunning])

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Navigation className="h-5 w-5 text-primary" />
          Mapa da Rota
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="relative">
          <div ref={mapRef} className="h-64 w-full rounded-b-lg" style={{ minHeight: "256px" }} />
          {!currentLocation && (
            <div className="absolute inset-0 flex items-center justify-center bg-muted/50 rounded-b-lg">
              <div className="text-center">
                <MapPin className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">Aguardando localização GPS...</p>
              </div>
            </div>
          )}
          {coordinates.length > 0 && (
            <div className="absolute top-2 left-2 bg-background/90 backdrop-blur-sm rounded px-2 py-1 text-xs">
              <span className="text-muted-foreground">Pontos: </span>
              <span className="font-semibold text-primary">{coordinates.length}</span>
            </div>
          )}
        </div>
      </CardContent>
      <style jsx>{`
        @keyframes pulse {
          0% { transform: scale(1); opacity: 1; }
          50% { transform: scale(1.2); opacity: 0.7; }
          100% { transform: scale(1); opacity: 1; }
        }
      `}</style>
    </Card>
  )
}
