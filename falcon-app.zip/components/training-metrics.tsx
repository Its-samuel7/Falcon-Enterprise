"use client"

import { Card, CardContent } from "@/components/ui/card"
import { MapPin, Clock, Zap, TrendingUp, Activity, Flame } from "lucide-react"

interface TrainingMetrics {
  distance: number
  duration: number
  averagePace: number
  currentSpeed: number
  elevationGain: number
  calories: number
}

interface TrainingMetricsProps {
  metrics: TrainingMetrics
  isTracking: boolean
}

export function TrainingMetricsDisplay({ metrics, isTracking }: TrainingMetricsProps) {
  const formatDistance = (meters: number): string => {
    if (meters < 1000) {
      return `${Math.round(meters)}m`
    }
    return `${(meters / 1000).toFixed(2)}km`
  }

  const formatDuration = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60

    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
    }
    return `${minutes}:${secs.toString().padStart(2, "0")}`
  }

  const formatPace = (secondsPerKm: number): string => {
    if (secondsPerKm === 0 || !isFinite(secondsPerKm)) return "--:--"
    const minutes = Math.floor(secondsPerKm / 60)
    const seconds = Math.floor(secondsPerKm % 60)
    return `${minutes}:${seconds.toString().padStart(2, "0")}`
  }

  const formatSpeed = (kmh: number): string => {
    return `${kmh.toFixed(1)} km/h`
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      <Card className={isTracking ? "ring-2 ring-primary/20" : ""}>
        <CardContent className="p-4 text-center">
          <MapPin className="w-6 h-6 text-primary mx-auto mb-2" />
          <div className="text-2xl font-bold">{formatDistance(metrics.distance)}</div>
          <div className="text-sm text-muted-foreground">distância</div>
        </CardContent>
      </Card>

      <Card className={isTracking ? "ring-2 ring-primary/20" : ""}>
        <CardContent className="p-4 text-center">
          <Clock className="w-6 h-6 text-accent mx-auto mb-2" />
          <div className="text-2xl font-bold">{formatDuration(metrics.duration)}</div>
          <div className="text-sm text-muted-foreground">tempo</div>
        </CardContent>
      </Card>

      <Card className={isTracking ? "ring-2 ring-primary/20" : ""}>
        <CardContent className="p-4 text-center">
          <Zap className="w-6 h-6 text-primary mx-auto mb-2" />
          <div className="text-2xl font-bold">{formatPace(metrics.averagePace)}</div>
          <div className="text-sm text-muted-foreground">ritmo/km</div>
        </CardContent>
      </Card>

      <Card className={isTracking ? "ring-2 ring-primary/20" : ""}>
        <CardContent className="p-4 text-center">
          <Activity className="w-6 h-6 text-accent mx-auto mb-2" />
          <div className="text-2xl font-bold">{formatSpeed(metrics.currentSpeed)}</div>
          <div className="text-sm text-muted-foreground">velocidade</div>
        </CardContent>
      </Card>

      <Card className={isTracking ? "ring-2 ring-primary/20" : ""}>
        <CardContent className="p-4 text-center">
          <TrendingUp className="w-6 h-6 text-primary mx-auto mb-2" />
          <div className="text-2xl font-bold">{Math.round(metrics.elevationGain)}m</div>
          <div className="text-sm text-muted-foreground">elevação</div>
        </CardContent>
      </Card>

      <Card className={isTracking ? "ring-2 ring-primary/20" : ""}>
        <CardContent className="p-4 text-center">
          <Flame className="w-6 h-6 text-accent mx-auto mb-2" />
          <div className="text-2xl font-bold">{metrics.calories}</div>
          <div className="text-sm text-muted-foreground">calorias</div>
        </CardContent>
      </Card>
    </div>
  )
}
