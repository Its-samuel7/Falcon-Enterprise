"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Download, ExternalLink, Star, BookOpen } from "lucide-react"
import Image from "next/image"

interface Book {
  id: number
  title: string
  author: string
  description: string
  category: string
  level: string
  pages: number
  rating: number
  downloadUrl: string
  coverImage: string
  tags: string[]
}

interface BookCardProps {
  book: Book
}

export function BookCard({ book }: BookCardProps) {
  const getLevelColor = (level: string) => {
    switch (level) {
      case "Iniciante":
        return "bg-green-500 text-white"
      case "Intermediário":
        return "bg-accent text-accent-foreground"
      case "Avançado":
        return "bg-primary text-primary-foreground"
      default:
        return "bg-secondary text-secondary-foreground"
    }
  }

  return (
    <Card className="hover:shadow-lg transition-shadow group">
      <CardContent className="p-4">
        <div className="relative mb-4">
          <Image
            src={book.coverImage || "/placeholder.svg"}
            alt={book.title}
            width={150}
            height={200}
            className="w-full h-48 object-cover rounded-lg"
          />
          <Badge className={`absolute top-2 right-2 ${getLevelColor(book.level)}`}>{book.level}</Badge>
        </div>

        <div className="space-y-3">
          <div>
            <h3 className="font-semibold text-lg line-clamp-2 group-hover:text-primary transition-colors">
              {book.title}
            </h3>
            <p className="text-sm text-muted-foreground">por {book.author}</p>
          </div>

          <p className="text-sm text-muted-foreground line-clamp-3">{book.description}</p>

          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <BookOpen className="w-3 h-3" />
              {book.pages} páginas
            </div>
            <div className="flex items-center gap-1">
              <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
              {book.rating}
            </div>
          </div>

          <div className="flex flex-wrap gap-1">
            {book.tags.slice(0, 3).map((tag) => (
              <Badge key={tag} variant="outline" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>

          <div className="flex gap-2 pt-2">
            <Button size="sm" className="flex-1 gap-2">
              <Download className="w-3 h-3" />
              Download
            </Button>
            <Button variant="outline" size="sm" className="gap-2 bg-transparent">
              <ExternalLink className="w-3 h-3" />
              Ver
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
