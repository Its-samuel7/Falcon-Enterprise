"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Plus, Target, Calendar, Clock, MapPin, Zap, TrendingUp, Trophy } from "lucide-react"

interface Goal {
  id: string
  name: string
  type: "distance" | "time" | "frequency" | "pace" | "elevation" | "calories"
  target: number
  current: number
  period: "daily" | "weekly" | "monthly" | "yearly"
  deadline?: Date
  isActive: boolean
  createdAt: Date
}

interface GoalsManagerProps {
  onBack: () => void
  savedRuns: Array<{
    id: string
    name: string
    date: Date
    distance: number
    duration: number
    pace: number
    elevationGain: number
  }>
}

export default function GoalsManager({ onBack, savedRuns }: GoalsManagerProps) {
  const [goals, setGoals] = useState<Goal[]>([])
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [newGoal, setNewGoal] = useState({
    name: "",
    type: "distance" as Goal["type"],
    target: 0,
    period: "weekly" as Goal["period"],
    deadline: "",
  })

  useEffect(() => {
    loadGoals()
  }, [])

  useEffect(() => {
    updateGoalProgress()
  }, [savedRuns, goals])

  const loadGoals = () => {
    const stored = localStorage.getItem("falcon-goals")
    if (stored) {
      const parsedGoals = JSON.parse(stored).map((goal: any) => ({
        ...goal,
        createdAt: new Date(goal.createdAt),
        deadline: goal.deadline ? new Date(goal.deadline) : undefined,
      }))
      setGoals(parsedGoals)
    }
  }

  const saveGoals = (updatedGoals: Goal[]) => {
    localStorage.setItem("falcon-goals", JSON.stringify(updatedGoals))
    setGoals(updatedGoals)
  }

  const updateGoalProgress = () => {
    const updatedGoals = goals.map((goal) => {
      const progress = calculateGoalProgress(goal)
      return { ...goal, current: progress }
    })
    if (JSON.stringify(updatedGoals) !== JSON.stringify(goals)) {
      setGoals(updatedGoals)
    }
  }

  const calculateGoalProgress = (goal: Goal): number => {
    const now = new Date()
    let startDate = new Date()

    switch (goal.period) {
      case "daily":
        startDate.setHours(0, 0, 0, 0)
        break
      case "weekly":
        startDate.setDate(now.getDate() - now.getDay())
        startDate.setHours(0, 0, 0, 0)
        break
      case "monthly":
        startDate = new Date(now.getFullYear(), now.getMonth(), 1)
        break
      case "yearly":
        startDate = new Date(now.getFullYear(), 0, 1)
        break
    }

    const relevantRuns = savedRuns.filter((run) => run.date >= startDate)

    switch (goal.type) {
      case "distance":
        return relevantRuns.reduce((sum, run) => sum + run.distance, 0)
      case "time":
        return relevantRuns.reduce((sum, run) => sum + run.duration, 0) / 60 // em minutos
      case "frequency":
        return relevantRuns.length
      case "pace":
        const avgPace =
          relevantRuns.length > 0 ? relevantRuns.reduce((sum, run) => sum + run.pace, 0) / relevantRuns.length : 0
        return avgPace > 0 ? Math.max(0, goal.target - avgPace) : 0
      case "elevation":
        return relevantRuns.reduce((sum, run) => sum + run.elevationGain, 0)
      case "calories":
        // Estimativa: ~60 calorias por km
        return relevantRuns.reduce((sum, run) => sum + run.distance * 60, 0)
      default:
        return 0
    }
  }

  const createGoal = () => {
    if (!newGoal.name || !newGoal.target) return

    const goal: Goal = {
      id: Date.now().toString(),
      name: newGoal.name,
      type: newGoal.type,
      target: newGoal.target,
      current: 0,
      period: newGoal.period,
      deadline: newGoal.deadline ? new Date(newGoal.deadline) : undefined,
      isActive: true,
      createdAt: new Date(),
    }

    const updatedGoals = [...goals, goal]
    saveGoals(updatedGoals)
    setShowCreateDialog(false)
    setNewGoal({
      name: "",
      type: "distance",
      target: 0,
      period: "weekly",
      deadline: "",
    })
  }

  const toggleGoal = (goalId: string) => {
    const updatedGoals = goals.map((goal) => (goal.id === goalId ? { ...goal, isActive: !goal.isActive } : goal))
    saveGoals(updatedGoals)
  }

  const deleteGoal = (goalId: string) => {
    const updatedGoals = goals.filter((goal) => goal.id !== goalId)
    saveGoals(updatedGoals)
  }

  const getGoalIcon = (type: Goal["type"]) => {
    switch (type) {
      case "distance":
        return <MapPin className="h-4 w-4" />
      case "time":
        return <Clock className="h-4 w-4" />
      case "frequency":
        return <Calendar className="h-4 w-4" />
      case "pace":
        return <Zap className="h-4 w-4" />
      case "elevation":
        return <TrendingUp className="h-4 w-4" />
      case "calories":
        return <Trophy className="h-4 w-4" />
    }
  }

  const formatGoalValue = (type: Goal["type"], value: number) => {
    switch (type) {
      case "distance":
        return `${value.toFixed(1)}km`
      case "time":
        return `${Math.floor(value)}min`
      case "frequency":
        return `${value} corridas`
      case "pace":
        return `${Math.floor(value)}:${Math.floor((value % 1) * 60)
          .toString()
          .padStart(2, "0")}/km`
      case "elevation":
        return `${Math.floor(value)}m`
      case "calories":
        return `${Math.floor(value)} cal`
    }
  }

  const getGoalTypeLabel = (type: Goal["type"]) => {
    switch (type) {
      case "distance":
        return "Distância"
      case "time":
        return "Tempo"
      case "frequency":
        return "Frequência"
      case "pace":
        return "Ritmo"
      case "elevation":
        return "Elevação"
      case "calories":
        return "Calorias"
    }
  }

  const getPeriodLabel = (period: Goal["period"]) => {
    switch (period) {
      case "daily":
        return "Diária"
      case "weekly":
        return "Semanal"
      case "monthly":
        return "Mensal"
      case "yearly":
        return "Anual"
    }
  }

  const activeGoals = goals.filter((goal) => goal.isActive)
  const completedGoals = goals.filter((goal) => !goal.isActive)

  return (
    <div className="min-h-screen bg-background p-4 space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={onBack}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="font-serif text-2xl font-bold text-primary">Metas</h1>
          <p className="text-muted-foreground">Defina e acompanhe seus objetivos</p>
        </div>
      </div>

      <div className="flex justify-between items-center">
        <div className="text-sm text-muted-foreground">{activeGoals.length} metas ativas</div>
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Nova Meta
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Criar Nova Meta</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="goal-name">Nome da Meta</Label>
                <Input
                  id="goal-name"
                  value={newGoal.name}
                  onChange={(e) => setNewGoal({ ...newGoal, name: e.target.value })}
                  placeholder="Ex: Correr 50km por semana"
                />
              </div>
              <div>
                <Label htmlFor="goal-type">Tipo</Label>
                <Select
                  value={newGoal.type}
                  onValueChange={(value: Goal["type"]) => setNewGoal({ ...newGoal, type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="distance">Distância</SelectItem>
                    <SelectItem value="time">Tempo</SelectItem>
                    <SelectItem value="frequency">Frequência</SelectItem>
                    <SelectItem value="pace">Ritmo</SelectItem>
                    <SelectItem value="elevation">Elevação</SelectItem>
                    <SelectItem value="calories">Calorias</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="goal-target">Meta</Label>
                <Input
                  id="goal-target"
                  type="number"
                  value={newGoal.target}
                  onChange={(e) => setNewGoal({ ...newGoal, target: Number.parseFloat(e.target.value) || 0 })}
                  placeholder="Valor da meta"
                />
              </div>
              <div>
                <Label htmlFor="goal-period">Período</Label>
                <Select
                  value={newGoal.period}
                  onValueChange={(value: Goal["period"]) => setNewGoal({ ...newGoal, period: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Diário</SelectItem>
                    <SelectItem value="weekly">Semanal</SelectItem>
                    <SelectItem value="monthly">Mensal</SelectItem>
                    <SelectItem value="yearly">Anual</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="goal-deadline">Prazo (opcional)</Label>
                <Input
                  id="goal-deadline"
                  type="date"
                  value={newGoal.deadline}
                  onChange={(e) => setNewGoal({ ...newGoal, deadline: e.target.value })}
                />
              </div>
              <Button onClick={createGoal} className="w-full">
                Criar Meta
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="active" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="active">Ativas ({activeGoals.length})</TabsTrigger>
          <TabsTrigger value="completed">Concluídas ({completedGoals.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="space-y-4">
          {activeGoals.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Target className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Nenhuma meta ativa</p>
                <p className="text-sm text-muted-foreground">Crie sua primeira meta para começar!</p>
              </CardContent>
            </Card>
          ) : (
            activeGoals.map((goal) => {
              const progress = (goal.current / goal.target) * 100
              const isCompleted = progress >= 100

              return (
                <Card key={goal.id} className={isCompleted ? "border-green-500" : ""}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {getGoalIcon(goal.type)}
                        <CardTitle className="text-lg">{goal.name}</CardTitle>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary">{getPeriodLabel(goal.period)}</Badge>
                        {isCompleted && <Badge className="bg-green-500">Concluída!</Badge>}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>{formatGoalValue(goal.type, goal.current)}</span>
                      <span>{formatGoalValue(goal.type, goal.target)}</span>
                    </div>
                    <Progress value={Math.min(progress, 100)} className="h-2" />
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-muted-foreground">{progress.toFixed(0)}% concluída</span>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => toggleGoal(goal.id)}>
                          {isCompleted ? "Arquivar" : "Pausar"}
                        </Button>
                        <Button variant="destructive" size="sm" onClick={() => deleteGoal(goal.id)}>
                          Excluir
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })
          )}
        </TabsContent>

        <TabsContent value="completed" className="space-y-4">
          {completedGoals.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Trophy className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Nenhuma meta concluída ainda</p>
              </CardContent>
            </Card>
          ) : (
            completedGoals.map((goal) => (
              <Card key={goal.id} className="opacity-75">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getGoalIcon(goal.type)}
                      <CardTitle className="text-lg">{goal.name}</CardTitle>
                    </div>
                    <Badge variant="outline">Arquivada</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between text-sm">
                    <span>
                      {getGoalTypeLabel(goal.type)} - {getPeriodLabel(goal.period)}
                    </span>
                    <span>{formatGoalValue(goal.type, goal.target)}</span>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
