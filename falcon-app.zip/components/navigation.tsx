"use client"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Home, Trophy, Users, Medal, Calendar, TrendingUp } from "lucide-react"

interface NavigationProps {
  currentView: string
  onViewChange: (view: string) => void
  userPoints: number
  unreadMessages: number
}

export default function Navigation({ currentView, onViewChange, userPoints, unreadMessages }: NavigationProps) {
  const navItems = [
    { id: "home", label: "Início", icon: Home },
    { id: "training", label: "Treinos", icon: Calendar },
    { id: "challenges", label: "Desafios", icon: Trophy },
    { id: "community", label: "Comunidade", icon: Users },
    { id: "achievements", label: "Conquistas", icon: Medal },
    { id: "analytics", label: "Análises", icon: TrendingUp },
  ]

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-background border-t border-border p-2">
      <div className="flex justify-around items-center max-w-md mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = currentView === item.id

          return (
            <Button
              key={item.id}
              variant={isActive ? "default" : "ghost"}
              size="sm"
              onClick={() => onViewChange(item.id)}
              className="flex flex-col items-center gap-1 h-auto py-2 px-3"
            >
              <div className="relative">
                <Icon className="h-4 w-4" />
                {item.id === "community" && unreadMessages > 0 && (
                  <Badge className="absolute -top-2 -right-2 h-4 w-4 p-0 text-xs">{unreadMessages}</Badge>
                )}
              </div>
              <span className="text-xs">{item.label}</span>
            </Button>
          )
        })}
      </div>

      <div className="text-center mt-2">
        <Badge variant="secondary" className="bg-primary/10 text-primary">
          {userPoints} pontos
        </Badge>
      </div>
    </div>
  )
}
