"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, Calendar, ExternalLink, User } from "lucide-react"

interface Article {
  id: number
  title: string
  author: string
  readTime: string
  publishDate: string
  excerpt: string
  url: string
  category: string
}

interface ArticleCardProps {
  article: Article
}

export function ArticleCard({ article }: ArticleCardProps) {
  const getCategoryColor = (category: string) => {
    switch (category) {
      case "technique":
        return "bg-primary text-primary-foreground"
      case "nutrition":
        return "bg-accent text-accent-foreground"
      case "training":
        return "bg-secondary text-secondary-foreground"
      case "injury":
        return "bg-destructive text-destructive-foreground"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  const getCategoryName = (category: string) => {
    switch (category) {
      case "technique":
        return "Técnica"
      case "nutrition":
        return "Nutrição"
      case "training":
        return "Treinamento"
      case "injury":
        return "Prevenção"
      default:
        return "Geral"
    }
  }

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="font-semibold text-lg hover:text-primary transition-colors cursor-pointer">
                {article.title}
              </h3>
              <Badge className={getCategoryColor(article.category)}>{getCategoryName(article.category)}</Badge>
            </div>
            <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
              <div className="flex items-center gap-1">
                <User className="w-3 h-3" />
                {article.author}
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {article.readTime}
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                {new Date(article.publishDate).toLocaleDateString("pt-BR")}
              </div>
            </div>
            <p className="text-muted-foreground mb-4">{article.excerpt}</p>
          </div>
        </div>
        <Button variant="outline" className="gap-2 bg-transparent">
          <ExternalLink className="w-4 h-4" />
          Ler Artigo
        </Button>
      </CardContent>
    </Card>
  )
}
