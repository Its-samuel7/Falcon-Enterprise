"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Clock, MapPin, Zap, Target, Play, CheckCircle, Star, TrendingUp } from "lucide-react"

interface TrainingSession {
  id: string
  name: string
  type: "easy" | "tempo" | "intervals" | "long" | "recovery"
  duration: number
  distance?: number
  intensity: "baixa" | "moderada" | "alta" | "máxima"
  description: string
  completed: boolean
  points: number
}

interface TrainingPlan {
  id: string
  name: string
  level: "iniciante" | "intermediário" | "avançado"
  duration: number // weeks
  description: string
  sessions: TrainingSession[]
  currentWeek: number
}

interface TrainingPlansProps {
  onBack: () => void
}

export default function TrainingPlans({ onBack }: TrainingPlansProps) {
  const [selectedPlan, setSelectedPlan] = useState<TrainingPlan | null>(null)
  const [userLevel, setUserLevel] = useState<"iniciante" | "intermediário" | "avançado">("iniciante")

  const trainingPlans: TrainingPlan[] = [
    {
      id: "5k-beginner",
      name: "Primeira 5K",
      level: "iniciante",
      duration: 8,
      description: "Plano para completar sua primeira corrida de 5km",
      currentWeek: 1,
      sessions: [
        {
          id: "1",
          name: "Corrida Leve",
          type: "easy",
          duration: 20,
          distance: 2,
          intensity: "baixa",
          description: "Corrida em ritmo confortável, deve conseguir conversar",
          completed: false,
          points: 50,
        },
        {
          id: "2",
          name: "Intervalado Básico",
          type: "intervals",
          duration: 25,
          intensity: "moderada",
          description: "5x 1min forte + 2min recuperação",
          completed: false,
          points: 75,
        },
        {
          id: "3",
          name: "Corrida Longa",
          type: "long",
          duration: 30,
          distance: 3,
          intensity: "baixa",
          description: "Corrida mais longa em ritmo bem confortável",
          completed: false,
          points: 100,
        },
      ],
    },
    {
      id: "10k-intermediate",
      name: "Desafio 10K",
      level: "intermediário",
      duration: 12,
      description: "Evolua para os 10km com treinos estruturados",
      currentWeek: 1,
      sessions: [
        {
          id: "4",
          name: "Tempo Run",
          type: "tempo",
          duration: 35,
          distance: 5,
          intensity: "alta",
          description: "Corrida em ritmo de prova, sustentado",
          completed: false,
          points: 120,
        },
        {
          id: "5",
          name: "Intervalado Avançado",
          type: "intervals",
          duration: 40,
          intensity: "máxima",
          description: "8x 400m + 90s recuperação",
          completed: false,
          points: 150,
        },
      ],
    },
    {
      id: "marathon-advanced",
      name: "Preparação Maratona",
      level: "avançado",
      duration: 16,
      description: "Plano completo para sua primeira maratona",
      currentWeek: 1,
      sessions: [
        {
          id: "6",
          name: "Longão",
          type: "long",
          duration: 120,
          distance: 20,
          intensity: "baixa",
          description: "Corrida longa para resistência aeróbica",
          completed: false,
          points: 200,
        },
      ],
    },
  ]

  const getIntensityColor = (intensity: string) => {
    switch (intensity) {
      case "baixa":
        return "bg-green-500"
      case "moderada":
        return "bg-yellow-500"
      case "alta":
        return "bg-orange-500"
      case "máxima":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "easy":
        return <MapPin className="h-4 w-4" />
      case "tempo":
        return <Zap className="h-4 w-4" />
      case "intervals":
        return <Target className="h-4 w-4" />
      case "long":
        return <TrendingUp className="h-4 w-4" />
      case "recovery":
        return <Star className="h-4 w-4" />
      default:
        return <Calendar className="h-4 w-4" />
    }
  }

  const filteredPlans = trainingPlans.filter((plan) => plan.level === userLevel)

  if (selectedPlan) {
    const completedSessions = selectedPlan.sessions.filter((s) => s.completed).length
    const totalSessions = selectedPlan.sessions.length
    const progress = (completedSessions / totalSessions) * 100

    return (
      <div className="min-h-screen bg-background p-4 pb-20 space-y-6">
        <div className="flex items-center justify-between">
          <Button variant="outline" onClick={() => setSelectedPlan(null)}>
            ← Voltar
          </Button>
          <Badge variant="secondary">{selectedPlan.level}</Badge>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary" />
              {selectedPlan.name}
            </CardTitle>
            <p className="text-sm text-muted-foreground">{selectedPlan.description}</p>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span>Progresso do Plano</span>
                <span>
                  {completedSessions}/{totalSessions} sessões
                </span>
              </div>
              <Progress value={progress} className="h-2" />
              <p className="text-xs text-muted-foreground">
                Semana {selectedPlan.currentWeek} de {selectedPlan.duration}
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <h3 className="font-semibold">Treinos da Semana</h3>
          {selectedPlan.sessions.map((session) => (
            <Card key={session.id} className={session.completed ? "bg-muted/50" : ""}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    {getTypeIcon(session.type)}
                    <h4 className="font-medium">{session.name}</h4>
                    {session.completed && <CheckCircle className="h-4 w-4 text-green-500" />}
                  </div>
                  <Badge variant="outline" className="text-xs">
                    +{session.points} pts
                  </Badge>
                </div>

                <p className="text-sm text-muted-foreground mb-3">{session.description}</p>

                <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
                  <div className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {session.duration}min
                  </div>
                  {session.distance && (
                    <div className="flex items-center gap-1">
                      <MapPin className="h-3 w-3" />
                      {session.distance}km
                    </div>
                  )}
                  <div className="flex items-center gap-1">
                    <div className={`h-2 w-2 rounded-full ${getIntensityColor(session.intensity)}`} />
                    {session.intensity}
                  </div>
                </div>

                {!session.completed && (
                  <Button size="sm" className="w-full">
                    <Play className="h-3 w-3 mr-1" />
                    Iniciar Treino
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background p-4 pb-20 space-y-6">
      <div className="flex items-center justify-between">
        <Button variant="outline" onClick={onBack}>
          ← Voltar
        </Button>
        <h1 className="font-serif text-2xl font-bold text-primary">Treinos Inteligentes</h1>
      </div>

      <Tabs value={userLevel} onValueChange={(value) => setUserLevel(value as any)}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="iniciante">Iniciante</TabsTrigger>
          <TabsTrigger value="intermediário">Intermediário</TabsTrigger>
          <TabsTrigger value="avançado">Avançado</TabsTrigger>
        </TabsList>

        <TabsContent value={userLevel} className="space-y-4 mt-6">
          {filteredPlans.map((plan) => (
            <Card key={plan.id} className="cursor-pointer hover:shadow-md transition-shadow">
              <CardContent className="p-4" onClick={() => setSelectedPlan(plan)}>
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-semibold">{plan.name}</h3>
                    <p className="text-sm text-muted-foreground">{plan.description}</p>
                  </div>
                  <Badge variant="secondary">{plan.duration} semanas</Badge>
                </div>

                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    {plan.sessions.length} treinos/semana
                  </div>
                  <div className="flex items-center gap-1">
                    <Target className="h-3 w-3" />
                    {plan.level}
                  </div>
                </div>

                <Button className="w-full mt-4" size="sm">
                  Começar Plano
                </Button>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  )
}
